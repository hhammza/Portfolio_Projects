CREATE DATABASE db_PharmacyProject
use db_PharmacyManagement

---------------------------------------------------------------CREATE TABLES------------------------------------------------
CREATE TABLE tbl_products(
   product_ID INT PRIMARY KEY IDENTITY(1,1),
    product_name VARCHAR(200) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price >= 0),
    cost_price DECIMAL(10, 2) NOT NULL CHECK (cost_price >= 0),
    Instock INT NOT NULL CHECK (Instock >= 0),
    stock_price DECIMAL(10, 2) NOT NULL CHECK (stock_price >= 0),
    batch_number INT NOT NULL,
    category VARCHAR(150) NOT NULL,
    manufacture_date DATE NOT NULL,
    exp_date DATE NOT NULL,
    CONSTRAINT chk_expiry CHECK (exp_date > manufacture_date),
);

CREATE TABLE tbl_product_history (
    product_ID INT, 
    change_date DATE,
    price DECIMAL(10,2),
    cost_price DECIMAL(10,2),
    PRIMARY KEY (product_ID, change_date), 
    FOREIGN KEY (product_ID) REFERENCES tbl_Products(product_ID) ON DELETE CASCADE 
);


CREATE TABLE tbl_product_backup (
    product_ID INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL CHECK (unit_price >= 0),
    cost_price DECIMAL(10, 2) NOT NULL CHECK (cost_price >= 0),
    Instock INT NOT NULL CHECK (Instock >= 0),
    stock_price DECIMAL(10, 2) NOT NULL CHECK (stock_price >= 0),
    batch_number INT NOT NULL,
    category VARCHAR(150) NOT NULL,
    manufacture_date DATE NOT NULL,
    exp_date DATE NOT NULL,
    deleted_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT check_expiry CHECK (exp_date > manufacture_date),
);


CREATE TABLE tbl_orders (
    order_ID INT PRIMARY KEY IDENTITY(1,1),
    product_ID INT NOT NULL,
    customer_ID INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL CHECK (amount >= 0),
    quantity INT NOT NULL CHECK (quantity >= 0),
    discount DECIMAL(10, 2) NOT NULL CHECK (discount >= 0),
    order_date DATE NOT NULL,
    delivery_date DATE NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    salesperson_ID INT NOT NULL,
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (customer_ID) REFERENCES tbl_customer(customer_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (salesperson_ID) REFERENCES tbl_salesperson(salesperson_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT chk_delivery_date CHECK (delivery_date >= order_date)
);

CREATE TABLE tbl_return_purchase (
    return_ID INT PRIMARY KEY IDENTITY(1,1),
    product_ID INT NOT NULL,
    customer_ID INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL CHECK (Amount >= 0),
    quantity INT NOT NULL CHECK (Quantity >= 0),
    discount DECIMAL(10, 2) NOT NULL CHECK (Discount >= 0),
    return_date DATE NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    salesperson_ID INT NOT NULL,
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (customer_ID) REFERENCES tbl_customer(customer_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (salesperson_ID) REFERENCES tbl_salesperson(salesperson_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE tbl_orderLine (
    order_ID INT NOT NULL,
    product_ID INT NOT NULL,
   -- quantity INT NOT NULL,
   -- price DECIMAL(10, 2) NOT NULL,
   -- total AS (quantity * price),  -- Removed the CHECK constraint on computed column
    PRIMARY KEY (order_ID, product_ID),
    FOREIGN KEY (order_ID) REFERENCES tbl_orders(order_ID),
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID)
);

CREATE TABLE tbl_customer (
    customer_ID INT PRIMARY KEY IDENTITY(1,1),
    customer_name VARCHAR(200) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL UNIQUE,
    customer_email VARCHAR(100) DEFAULT 'not_provided',
    customer_address VARCHAR(255) DEFAULT 'not_provided'
);

CREATE TABLE tbl_customer_backup (
    customer_ID INT NOT NULL,
    customer_name VARCHAR(200) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(100) DEFAULT 'not_provided',
    customer_address VARCHAR(255) DEFAULT 'not_provided',
    deleted_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE tbl_salesperson (
    salesperson_ID INT PRIMARY KEY IDENTITY(1,1),
    salesperson_name VARCHAR(200) NOT NULL,
    salesperson_phone VARCHAR(20) NOT NULL UNIQUE,
    salesperson_email VARCHAR(100) NOT NULL UNIQUE,
    salesperson_address VARCHAR(255) NOT NULL,
    salesperson_login_mail VARCHAR(100) NOT NULL UNIQUE,
    salesperson_mail_password VARCHAR(100) NOT NULL
);

CREATE TABLE tbl_supplier (
    supplier_ID INT PRIMARY KEY IDENTITY(1,1),
    supplier_name VARCHAR(200) NOT NULL,
    supplier_phone VARCHAR(20) UNIQUE NOT NULL,
    supplier_email VARCHAR(100) UNIQUE DEFAULT 'not_provided',
	supplier_address VARCHAR(255) NOT NULL,
    supplier_registration_date DATE DEFAULT GETDATE()
);

CREATE TABLE tbl_supplier_backup (
    supplier_ID INT NOT NULL,
    supplier_name VARCHAR(200) NOT NULL,
    supplier_phone VARCHAR(20) NOT NULL,
    supplier_email VARCHAR(100) DEFAULT 'not_provided',
    supplier_address VARCHAR(255) NOT NULL,
    supplier_registration_date DATE DEFAULT GETDATE(),
    deleted_at DATETIME DEFAULT GETDATE()
);

CREATE TABLE tbl_product_supplier (
    product_ID INT NOT NULL,
    supplier_ID INT NOT NULL,
    PRIMARY KEY (product_ID, supplier_ID),
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    FOREIGN KEY (supplier_ID) REFERENCES tbl_supplier(supplier_ID) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE
);

CREATE TABLE tbl_manufacturer (
    manufacturer_ID INT PRIMARY KEY IDENTITY(1,1),
    manufacturer_name VARCHAR(200) NOT NULL,
    manufacturer_phone VARCHAR(20) UNIQUE NOT NULL,
    manufacturer_email VARCHAR(100) NOT NULL UNIQUE,
	manufacturer_address VARCHAR(255) NOT NULL
);

CREATE TABLE tbl_manufacturer_backup (
    manufacturer_ID INT NOT NULL,
    manufacturer_name VARCHAR(200) NOT NULL,
    manufacturer_phone VARCHAR(20) NOT NULL,
    manufacturer_email VARCHAR(100) NOT NULL,
    manufacturer_address VARCHAR(255) NOT NULL,
    deleted_at DATETIME DEFAULT GETDATE()
);


CREATE TABLE tbl_product_manufacturer (
    product_ID INT NOT NULL,
    manufacturer_ID INT NOT NULL,
    PRIMARY KEY (product_ID, manufacturer_ID),
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    FOREIGN KEY (manufacturer_ID) REFERENCES tbl_manufacturer(manufacturer_ID) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE
);

CREATE TABLE tbl_discount (
    discount_ID INT PRIMARY KEY IDENTITY(1,1),
    Amount DECIMAL(10, 2) NOT NULL CHECK (Amount >= 0)
);

CREATE TABLE tbl_product_discount(
    discount_ID INT,
    product_ID INT,
    PRIMARY KEY (discount_ID, product_ID),
    FOREIGN KEY (discount_ID) REFERENCES tbl_discount(discount_ID),
    FOREIGN KEY (product_ID) REFERENCES tbl_products(product_ID)
);

CREATE TABLE tbl_ReportInventory (
    report_ID INT PRIMARY KEY IDENTITY(1,1),
    stock_category VARCHAR(255) NOT NULL,
    stock_group VARCHAR(200) NOT NULL,
    category_group VARCHAR(200) NOT NULL,
    manufacturer VARCHAR(200) NOT NULL
);

CREATE TABLE tbl_inventory_change_history (
    product_ID INT,
    change_date DATE,
    PRIMARY KEY (product_ID, change_date),
    FOREIGN KEY (product_ID) REFERENCES tbl_Products(product_ID)
);