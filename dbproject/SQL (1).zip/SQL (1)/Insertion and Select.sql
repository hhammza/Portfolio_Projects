use db_PharmacyManagement
---------------------------------------------------------------Data Insertion------------------------------------------------
-- Insert Data into tbl_Products
INSERT INTO tbl_Products (product_name, unit_price, cost_price, Instock, batch_number, category, manufacture_date, exp_date)
VALUES
('Cetirizine Tablets', 10.0, 7.2, 500, 101, 'Antihistamine', '2023-01-15', '2025-01-15'),
('Loratadine Tablets', 12.5, 11.8, 450, 102, 'Antihistamine', '2023-02-15', '2025-02-15'),
('Ibuprofen Tablets', 13.0, 8.0, 700, 103, 'Pain Reliever', '2023-03-10', '2025-03-10'),
('Diclofenac Gel', 140.0, 113.5, 300, 104, 'Topical', '2023-04-01', '2025-04-01'),
('Omeprazole Capsules', 33.0, 22.0, 800, 105, 'Antacid', '2023-05-01', '2025-05-01'),
('Ciprofloxacin Tablets', 15.0, 9.5, 500, 106, 'Antibiotic', '2023-06-01', '2025-06-01'),
('Metformin Tablets', 16.0, 5.0, 600, 107, 'Diabetes', '2023-07-01', '2025-07-01'),
('Salbutamol Inhaler', 29.0, 17.0, 200, 108, 'Asthma', '2023-08-01', '2025-08-01'),
('Paracetamol Suspension', 44.0, 23.0, 650, 109, 'Syrup', '2023-09-01', '2025-09-01'),
('Amoxicillin Syrup', 130.0, 92.0, 500, 110, 'Antibiotic', '2023-10-01', '2025-10-01'),
('Prednisolone Tablets', 47.0, 36.0, 700, 111, 'Steroid', '2023-11-01', '2025-11-01'),
('Miconazole Cream', 185.0, 154.0, 400, 112, 'Antifungal', '2023-12-01', '2025-12-01'),
('Diphenhydramine Syrup', 134.0, 123.5, 300, 113, 'Antihistamine', '2024-01-20', '2024-02-01'),
('Calcium Carbonate Tablets', 63.0, 52.5, 1000, 114, 'Supplement', '2024-02-01', '2026-02-01'),
('Glyceryl Trinitrate Tablets', 32.0, 20.0, 150, 115, 'Cardiac', '2024-03-01', '2026-03-01'),
('Sodium Chloride Nasal Spray', 200.0, 180.0, 300, 116, 'Nasal Care', '2024-04-01', '2026-04-01'),
('Chlorhexidine Mouthwash', 250.0, 200.0, 600, 117, 'Oral Care', '2024-05-01', '2026-05-01'),
('Zinc Sulfate Tablets', 33.0, 22.0, 800, 118, 'Supplement', '2024-06-01', '2026-06-01'),
('Folic Acid Tablets', 42.0, 31.0, 1000, 119, 'Supplement', '2024-07-10', '2024-08-01'),
('Vitamin C Tablets', 24.0, 18.0, 700, 120, 'Supplement', '2024-08-01', '2026-08-01'),
('Pampers Size 2', 300.0, 280.0, 300, 121, 'Baby Care', '2024-01-01', '2026-01-01'),
('Powder Milk Formula', 500.0, 490.0, 150, 122, 'Baby Care', '2024-02-01', '2026-02-01'),
('Baby Feeder', 150.0, 145.0, 200, 123, 'Baby Care', '2024-03-01', '2026-03-01'),
('Surgical Mask', 15, 4.8, 1000, 124, 'Hygiene', '2024-04-01', '2026-04-01'),
('Syringe 5ml', 20, 10, 2000, 125, 'Medical Equipment', '2024-05-01', '2026-05-01'),
('Panadol Tablets', 40.0,30.0, 80,126,'Pain Killer', '2024-01-15', '2024-12-30');

-- Insert Data into tbl_Salesperson 
INSERT INTO tbl_Salesperson (salesperson_name, salesperson_phone, salesperson_email, salesperson_address, salesperson_login_mail, salesperson_mail_password)
VALUES
('Ali Ahmed', '03341234567', 'ali.ahmed@example.com', '123 Shahrah-e-Faisal, Lahore', 'ali.ahmed@company.com', 'password123'),
('Sarah Khan', '03352456789', 'sarah.khan@example.com', '456 Mall Road, Lahore', 'sarah.khan@company.com', 'securePass!'),
('Omer Malik', '03451234567', 'omer.malik@example.com', '789 Saddar, Lahore', 'omer.malik@company.com', 'password321'),
('Zara Ali', '03261234567', 'zara.ali@example.com', '321 Gulberg, Lahore', 'zara.bibi@company.com', 'password123!'),
('Usman Javed', '03367654321', 'usman.javed@example.com', '654 Lahore Road, Lahore', 'usman.javed@company.com', 'usman2024');

-- Insert Data into tbl_Supplier
INSERT INTO tbl_Supplier (supplier_name, supplier_address, supplier_phone, supplier_email)
VALUES
('Pak Medical Supplies', 'Karachi, Pakistan', '+923008244589', 'info@pakmedicalsupplies.com'),
('Hospital Supply Corporation (HSC)', 'Block VI, P.E.C.H.S, Karachi', '+922134303170', 'info@hsc.com.pk'),
('Medivision', 'Johar Town, Lahore', '+923214567890', 'support@medivision.pk'),
('Health Care Devices', 'Saddar, Rawalpindi', '+923005678912', 'contact@healthcaredevices.pk'),
('Pharmatech Pakistan', 'Gulberg III, Lahore', '+923336789123', 'info@pharmatech.com.pk');

-- Insert Data into tbl_Manufacturer
INSERT INTO tbl_Manufacturer (manufacturer_name, manufacturer_phone, manufacturer_address, manufacturer_email)
VALUES
('Hilton Pharma', '03001234567', 'Karachi, Sindh', 'info@hiltonpharma.com'),
('Macter International', '03011234567', 'Karachi, Sindh', 'contact@macter.com'),
('Searle Pakistan', '03021234567', 'Karachi, Sindh', 'support@searlepak.com'),
('Abbott Pakistan', '03031234567', 'Lahore, Punjab', 'info@abbott.com'),
('Sanofi Aventis', '03041234567', 'Islamabad, Capital Territory', 'help@sanofi.com');

-- Insert Data into tbl_product_supplier
INSERT INTO tbl_product_supplier (product_ID, supplier_ID)
VALUES
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5),
(6, 1), (7, 2), (8, 3), (9, 4), (10, 5),
(11, 1), (12, 2), (13, 3), (14, 4), (15, 5),
(16, 1), (17, 2), (18, 3), (19, 4), (20, 5),
(21, 3), (22, 3), (23, 3), (24, 4), (25, 4),(26,5);

-- Insert Data into tbl_product_manufacturer
INSERT INTO tbl_product_manufacturer (product_ID, manufacturer_ID)
VALUES
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5),
(6, 1), (7, 2), (8, 3), (9, 4), (10, 5),
(11, 1), (12, 2), (13, 3), (14, 4), (15, 5),
(16, 1), (17, 2), (18, 3), (19, 4), (20, 5),
(21, 1), (22, 3), (23, 1), (24, 1), (25, 3),(26,1);

INSERT INTO tbl_ReportInventory (stock_category, stock_group, category_group, manufacturer)
VALUES
('Medicines', 'Tablets', 'Pain Relief', 'Hilton Pharma'),
('Medicines', 'Syrups', 'Cough & Cold', 'Searle Pakistan'),
('Medicines', 'Injections', 'Diabetes Care', 'Sanofi Aventis'),
('Medicines', 'Capsules', 'Antibiotics', 'Abbott Pakistan'),
('Medicines', 'Tablets', 'Pain Relief', 'GlaxoSmithKline'),
('Medicines', 'Syrups', 'Cough & Cold', 'Medisave Pvt Ltd'),
('Medicines', 'Injections', 'Diabetes Care', 'Crown Pharmaceuticals'),
('Medicines', 'Tablets', 'Antidiarrheal', 'Maple Pharma'),
('Medical Equipment', 'Diagnostic Tools', 'Monitoring Devices', 'Hilton Pharma'),
('Medical Equipment', 'Surgical Tools', 'Minor Procedures', 'Searle Pakistan'),
('Medical Equipment', 'Diagnostic Tools', 'Blood Pressure Monitoring', 'Sanofi Aventis'),
('Medical Equipment', 'Surgical Tools', 'Sutures & Staplers', 'Abbott Pakistan'),
('Personal Protective Equipment', 'Masks', 'Face Protection', 'GlaxoSmithKline'),
('Personal Protective Equipment', 'Sanitizers', 'Hand Hygiene', 'Macter International'),
('Personal Protective Equipment', 'Face Shields', 'Face Protection', 'Maple Pharma'),
('Supplements', 'Multivitamins', 'General Health', 'Novartis Pharma'),
('Supplements', 'Energy Drinks', 'Nutrition', 'Abbott Pakistan'),
('Supplements', 'Proteins', 'Body Building', 'Sanofi Aventis'),
('Personal Care', 'Hair Care', 'Shampoos', 'Medisave Pvt Ltd'),
('Personal Care', 'Skin Care', 'Moisturizers', 'Hilton Pharma'),
('Medical Equipment', 'Diagnostic Tools', 'X-ray Machines', 'Abbott Pakistan'),
('Medical Equipment', 'Surgical Tools', 'Orthopedic Tools', 'Crown Pharmaceuticals'),
('Medicines', 'Inhalers', 'Respiratory Care', 'Sanofi Aventis'),
('Medicines', 'Patches', 'Pain Relief', 'Abbott Pakistan'),
('Personal Protective Equipment', 'Gloves', 'Hand Protection', 'Hilton Pharma'),
('Medicines', 'Injections', 'Vaccines', 'GlaxoSmithKline'),
('Medicines', 'Tablets', 'Heart Health', 'Macter International'),
('Medical Equipment', 'Diagnostic Tools', 'ECG Machines', 'Maple Pharma'),
('Medicines', 'Oral Liquids', 'Digestive Health', 'Abbott Pakistan'),
('Medical Equipment', 'Surgical Tools', 'Scalpels', 'Searle Pakistan'),
('Supplements', 'Vitamins', 'Immunity Boosters', 'Sanofi Aventis'),
('Medicines', 'Tablets', 'Allergy Relief', 'Macter International'),
('Medical Equipment', 'Thermometers', 'Body Temperature Monitoring', 'Hilton Pharma'),
('Medicines', 'Capsules', 'Pain Relief', 'Abbott Pakistan'),
('Supplements', 'Minerals', 'Bone Health', 'Novartis Pharma'),
('Personal Care', 'Hair Care', 'Conditioners', 'Medisave Pvt Ltd'),
('Personal Care', 'Skin Care', 'Sunscreens', 'GlaxoSmithKline'),
('Medicines', 'Pills', 'Womens Health', 'Sanofi Aventis'),
('Medical Equipment', 'Surgical Tools', 'Bone Surgery', 'Crown Pharmaceuticals'),
('Medicines', 'Creams', 'Topical Treatments', 'Macter International'),
('Personal Protective Equipment', 'Boots', 'Foot Protection', 'Abbott Pakistan'),
('Supplements', 'Herbal Products', 'Natural Remedies', 'Maple Pharma'),
('Medicines', 'Vitamins', 'Fatigue Relief', 'Medisave Pvt Ltd'),
('Personal Care', 'Dental Care', 'Toothpastes', 'Abbott Pakistan'),
('Medicines', 'Tablets', 'Cholesterol Control', 'Hilton Pharma'),
('Supplements', 'Energy Bars', 'Nutrition', 'Searle Pakistan'),
('Medical Equipment', 'Surgical Tools', 'Dental Equipment', 'Abbott Pakistan'),
('Personal Care', 'Foot Care', 'Creams & Lotions', 'Novartis Pharma'),
('Medicines', 'Ointments', 'Skin Treatments', 'Sanofi Aventis'),
('Medicines', 'Capsules', 'Immunity Boosters', 'Searle Pakistan'),
('Medical Equipment', 'Diagnostic Tools', 'Ophthalmic Instruments', 'Maple Pharma'),
('Medicines', 'Syrups', 'Antipyretics', 'Macter International'),
('Supplements', 'Herbal Tea', 'Stress Relief', 'Sanofi Aventis');





----------------------------------------------------------------------------------------------
--------------------------------------------Dont Insert Just For checking Database these table will be inserted by GUI--------------------------


-- Insert Data into tbl_Customer 
INSERT INTO tbl_Customer (customer_name, customer_phone, customer_email, customer_address)
VALUES
('Hassaan Asghar', '034563289445', 'hanno404@gmail.com', '500-B OO-street, Okara'),
('Hamza Afzal', '033224455667', 'hamza404@gmail.com', '600-H Hanjarwal, Lahore'),
('Muhammad Faizan', '03324220221', 'fxd888@gmail.com', '813-D street 21 DHA phase 6, Lahore');

INSERT INTO tbl_orders(product_Id, customer_Id, amount, quantity, discount, order_date, delivery_date, payment_method, salesperson_Id)
VALUES
(20,	3, 48, 2, 4,	'2024-12-15', '2024-12-15', 'Cash', 2);
(1,	1, 245.00, 5, 5.00,	'2024-11-24', '2024-11-24', 'Cash', 1),
(1,	2, 100, 10, 5.00,	'2024-11-24', '2024-11-24', 'Credit Card', 1);


INSERT INTO tbl_orderLine(product_Id, order_Id, quantity, price)
VALUES
(1,1,5,50);

-- Insert Data into tbl_Discount (Discount amounts ranging from 4% to 14%)
INSERT INTO tbl_Discount (amount)
VALUES
(0),(4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14);

-- Insert Data into tbl_Product_Discount (Assigning discounts to products)
INSERT INTO tbl_Product_Discount (product_ID, discount_ID)
VALUES
(20,2);, (2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 8), (9, 9), (10, 10),
-------------------------------------------------------------------------------------------------------------------

------------------------------------------------Delete and Update--------------------------------------------------
UPDATE tbl_products
SET 
    product_name = 'Paracetamol Suspension',
    unit_price = 40.50,
    cost_price = 30.00,
    Instock = 200,
    batch_number = 2024,
    category = 'Pain Killer',
    manufacture_date = '2024-01-01',
    exp_date = '2024-12-25'
WHERE 
    product_ID = 9 ;

-- Delete from dependent table first
DELETE FROM tbl_products
WHERE product_ID = 23;

DELETE FROM tbl_product_manufacturer
WHERE product_ID = 19;

DELETE FROM tbl_product_backup
WHERE product_ID = 23;

DELETE FROM tbl_customer_backup
WHERE customer_Id = 1;

DELETE FROM tbl_supplier_backup
WHERE supplier_Id = 6;


-- Then delete the product
DELETE FROM tbl_manufacturer_backup
WHERE manufacturer_Id  = 3;
-- Enable IDENTITY_INSERT for tbl_products

SELECT * FROM tbl_products WHERE product_ID = 19;
-- Turn on IDENTITY_INSERT to allow manual insert of identity column
SET IDENTITY_INSERT tbl_products ON;

-- Insert the data from backup for product_ID 19
INSERT INTO tbl_products (
    product_ID,
    product_name,
    unit_price,
    cost_price,
    Instock,
    stock_price,
    batch_number,
    category,
    manufacture_date,
    exp_date
)
SELECT 
    product_ID,
    product_name,
    unit_price,
    cost_price,
    Instock,
    stock_price,
    batch_number,
    category,
    manufacture_date,
    exp_date
FROM tbl_product_backup
WHERE product_ID = 19;

-- Turn off IDENTITY_INSERT after the insert
SET IDENTITY_INSERT tbl_products OFF;

SELECT * FROM tbl_product_backup WHERE product_ID = 19;

--------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------Show Tables------------------------------------------------------
--show tables
SELECT * FROM tbl_products;
SELECT * FROM tbl_product_backup;
SELECT * FROM tbl_product_history;
SELECT * FROM tbl_orderline;
SELECT * FROM tbl_orders;
SELECT * FROM tbl_customer;
SELECT * FROM tbl_customer_backup;
SELECT * FROM tbl_salesperson;
SELECT * FROM tbl_supplier;
SELECT * FROM tbl_supplier_backup;
SELECT * FROM tbl_product_supplier;
SELECT * FROM tbl_manufacturer;
SELECT * FROM tbl_manufacturer_backup;
SELECT * FROM tbl_product_manufacturer;
SELECT * FROM tbl_product_discount;
SELECT * FROM tbl_discount;
SELECT * FROM tbl_ReportInventory;
SELECT * FROM tbl_inventory_change_history;