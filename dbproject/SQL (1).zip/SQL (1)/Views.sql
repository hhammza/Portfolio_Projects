use db_PharmacyManagement
-------------------------------------------------------- views----------------------------------------------------- 
--view
CREATE VIEW view_ProductDetails AS
SELECT 
    p.product_name AS [Product Name],
    o.amount AS [Amount],
    p.manufacture_date AS [Manufacture Date],
    p.exp_date AS [Exppiry Date],
    p.category AS [Category],
    o.quantity AS [Quantity],
    d.Amount AS [Discount]
FROM 
    tbl_products p
JOIN 
    tbl_orders o ON p.product_ID = o.product_ID
LEFT JOIN 
    tbl_product_discount pd ON p.product_ID = pd.product_ID
LEFT JOIN 
    tbl_discount d ON pd.discount_ID = d.discount_ID;


-- Product Supply Chain View
CREATE VIEW view_ProductSupplyChain AS
SELECT 
    p.product_ID AS "ProductID", 
    p.product_name AS "Product Name",
    p.category AS "Category",
    p.unit_price AS "Selling Price",        
    p.cost_price AS "Cost Price",
    p.Instock AS "Stock",
    p.stock_price AS "Stock Price",         
    p.manufacture_date AS "Manufacture Date",   
    p.exp_date AS "Expiry Date",           
    p.batch_number AS "Batch Number", 
    s.supplier_ID AS "Supplier ID", 
    s.supplier_name AS "Supplier Name", 
    m.manufacturer_ID AS "Manufacturer ID", 
    m.manufacturer_name AS "Manufacturer Name"
FROM 
    tbl_Products p
JOIN 
    tbl_Product_Supplier ps ON p.product_ID = ps.product_ID
JOIN 
    tbl_Supplier s ON ps.supplier_ID = s.supplier_ID
JOIN 
    tbl_Product_Manufacturer pm ON p.product_ID = pm.product_ID
JOIN 
    tbl_Manufacturer m ON pm.manufacturer_ID = m.manufacturer_ID;

-- To view all or specific product details:
SELECT * FROM view_ProductSupplyChain 

SELECT * 
FROM view_ProductSupplyChain 
WHERE "Product Name" = 'Paracetamol Suspension';

-------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE VIEW view_product AS
SELECT 
    product_name, 
    unit_price, 
    cost_price, 
    manufacture_date, 
    exp_date, 
    Instock, 
    category
FROM 
    tbl_Products;


-------------------------------------------------------------------------------------------------------------------

--View of Most sold product
CREATE VIEW view_MostSoldProducts AS
SELECT 
    p.product_ID AS "Product ID",
    p.product_name AS "Product Name",
    SUM(o.quantity) AS "Total Quantity Sold",
    SUM((p.unit_price * o.quantity) - ISNULL(d.Amount, 0)) AS "Total Sales",
    SUM(((p.unit_price - p.cost_price) * o.quantity) - ISNULL(d.Amount, 0)) AS "Total Profit"
FROM 
    tbl_orders o
JOIN 
    tbl_products p ON o.product_ID = p.product_ID
LEFT JOIN 
    tbl_product_discount pd ON p.product_ID = pd.product_ID
LEFT JOIN 
    tbl_discount d ON pd.discount_ID = d.discount_ID
GROUP BY 
    p.product_ID, p.product_name;

-- To view the most sold products in descending order by total profit:
SELECT * 
FROM view_MostSoldProducts
ORDER BY [Total Profit] DESC;

-------------------------------------------------------------------------------------------------------------------

--View of Product Change History
CREATE VIEW view_ProductChangeHistory AS
SELECT 
    h.product_ID AS "Product ID", 
    p.product_name AS "Product Name", 
    p.category AS "Category", 
    p.unit_price AS "Unit Price", 
    p.cost_price AS "Cost Price", 
    h.change_date AS "Change Date"
FROM 
    tbl_product_history h
JOIN 
    tbl_Products p ON h.product_ID = p.product_ID;

-- To view product change history:
SELECT * FROM view_ProductChangeHistory;

-----------------------------------------------------------------------------------------------------------------

--View of product that will expire in near future
CREATE VIEW view_NearExpiryProducts AS
SELECT 
    product_ID AS "Product ID", 
    product_name AS "Product Name", 
    category AS "Category", 
    unit_price AS "Unit Price", 
    cost_price AS "Cost Price", 
    Instock AS "Stock Quantity", 
    batch_number AS "Batch Number", 
    manufacture_date AS "Manufacture Date", 
    exp_date AS "Expiry Date"
FROM 
    tbl_Products
WHERE 
    exp_date BETWEEN GETDATE() AND DATEADD(DAY, 30, GETDATE());

-- To view products with near expiry dates:
SELECT * FROM view_NearExpiryProducts;

-------------------------------------------------------------------------------------------------------------------

-- Low Stock of Products view 
CREATE VIEW view_LowStockProducts AS
SELECT 
    p.product_ID AS "ProductID", 
    p.product_name AS "Product Name", 
    p.cost_price AS "Cost Price", 
    p.Instock AS "Stock Quantity",  
    p.batch_number AS "Batch Number", 
    p.category AS "Category", 
    s.supplier_ID AS "Supplier ID", 
    s.supplier_name AS "Supplier Name", 
    s.supplier_phone AS "Supplier Phone", 
    s.supplier_email AS "Supplier Email", 
    m.manufacturer_ID AS "Manufacturer ID", 
    m.manufacturer_name AS "Manufacturer Name", 
    m.manufacturer_phone AS "Manufacturer Phone", 
    m.manufacturer_email AS "Manufacturer Email"
FROM 
    tbl_Products p
JOIN 
    tbl_Product_Supplier ps ON p.product_ID = ps.product_ID
JOIN 
    tbl_Supplier s ON ps.supplier_ID = s.supplier_ID
JOIN 
    tbl_Product_Manufacturer pm ON p.product_ID = pm.product_ID
JOIN 
    tbl_Manufacturer m ON pm.manufacturer_ID = m.manufacturer_ID
WHERE 
    p.Instock < 100;

-- To view Low Stock of Products:
SELECT * FROM view_LowStockProducts
SELECT * FROM view_LowStockProducts ORDER BY [Stock Quantity] ASC;

-------------------------------------------------------------------------------------------------------------------

--View of all Bills
CREATE VIEW view_billing AS
SELECT 
    o.order_ID AS OrderID,
    o.order_date AS OrderDate,
    c.customer_name AS CustomerName,
    p.product_name AS ProductName,
    o.quantity AS Quantity,
    p.unit_price AS UnitPrice,
    d.amount AS Discount,
    (o.quantity * p.unit_price) - ISNULL(d.amount, 0) AS TotalAmount,
    o.payment_method AS PaymentMethod,
    s.salesperson_name AS SalespersonName
FROM 
    tbl_Orders o
INNER JOIN 
    tbl_Customer c ON o.customer_ID = c.customer_ID
INNER JOIN 
    tbl_Products p ON o.product_ID = p.product_ID
LEFT JOIN 
    tbl_Product_Discount pd ON p.product_ID = pd.product_ID
LEFT JOIN 
    tbl_Discount d ON pd.discount_ID = d.discount_ID
INNER JOIN 
    tbl_Salesperson s ON o.salesperson_ID = s.salesperson_ID;

-- To view all or specific billing records:
SELECT * FROM view_Billing where OrderID = 1;
SELECT * FROM view_Billing where CustomerName = 'Hassaan Asghar';
SELECT * FROM view_Billing

---------------------------------------------------------------------------------------------------------------------

--View of today's bill only
CREATE VIEW view_TodaysBilling AS
SELECT 
    o.order_ID AS OrderID,
    o.order_date AS OrderDate,
    c.customer_name AS CustomerName,
    p.product_name AS ProductName,
    o.quantity AS Quantity,
    p.unit_price AS UnitPrice,
    d.amount AS Discount,
    (o.quantity * p.unit_price) - ISNULL(d.amount, 0) AS TotalAmount,
    o.payment_method AS PaymentMethod,
    s.salesperson_name AS SalespersonName
FROM 
    tbl_Orders o
INNER JOIN 
    tbl_Customer c ON o.customer_ID = c.customer_ID
INNER JOIN 
    tbl_Products p ON o.product_ID = p.product_ID
LEFT JOIN 
    tbl_Product_Discount pd ON p.product_ID = pd.product_ID
LEFT JOIN 
    tbl_Discount d ON pd.discount_ID = d.discount_ID
INNER JOIN 
    tbl_Salesperson s ON o.salesperson_ID = s.salesperson_ID
WHERE 
    CAST(o.order_date AS DATE) = CAST(GETDATE() AS DATE);

-- To view today's billing records:
SELECT * FROM view_TodaysBilling;

----------------------------------------------------------------------------------------------------------------------

--To View orders by date
CREATE VIEW view_BillsByDate AS
SELECT 
    o.order_ID AS OrderID,
    o.order_date AS OrderDate,
    c.customer_name AS CustomerName,
    p.product_name AS ProductName,
    o.quantity AS Quantity,
    p.unit_price AS UnitPrice,
    d.amount AS Discount,
    (o.quantity * p.unit_price) - d.Amount AS TotalAmount,
    o.payment_method AS PaymentMethod,
    s.salesperson_name AS SalespersonName
FROM 
    tbl_Orders o
INNER JOIN 
    tbl_Customer c ON o.customer_ID = c.customer_ID
INNER JOIN 
    tbl_orderLine ol ON o.order_ID = ol.order_ID
INNER JOIN 
    tbl_Products p ON ol.product_ID = p.product_ID
LEFT JOIN 
    tbl_Product_Discount pd ON p.product_ID = pd.product_ID
LEFT JOIN 
    tbl_Discount d ON pd.discount_ID = d.discount_ID
INNER JOIN 
    tbl_Salesperson s ON o.salesperson_ID = s.salesperson_ID;

SELECT * 
FROM view_BillsByDate
WHERE OrderDate BETWEEN '2024-01-01' AND '2024-12-31';

---------------------------------------------------------------------------------------------------------------------

--View of customer purcahse history
CREATE VIEW view_CustomerPurchaseHistory AS
SELECT 
    c.customer_ID AS "Customer ID",
    c.customer_name AS "Customer Name",
    p.product_name AS "Product Name",
    o.quantity AS "Quantity Purchased",
    (p.unit_price * o.quantity)-d.Amount AS "Total Amount",
    o.order_date AS "Order Date"
FROM 
    tbl_Customer c
JOIN 
    tbl_Orders o ON c.customer_ID = o.customer_ID
JOIN 
    tbl_Products p ON o.product_ID = p.product_ID
JOIN 
    tbl_product_discount pd ON p.product_ID = pd.product_ID
JOIN 
    tbl_discount d ON pd.discount_ID = d.discount_ID;

-- To view purchase history of customers:
SELECT * FROM view_CustomerPurchaseHistory WHERE "Customer Name" = 'Hamza Afzal';

---------------------------------------------------------------------------------------------------------------------

--View of zero discount products
CREATE VIEW view_ProductsZeroDiscount AS
SELECT 
    p.product_ID AS "Product ID", 
    p.product_name AS "Product Name", 
    p.category AS "Category", 
    p.unit_price AS "Unit Price", 
    p.Instock AS "Stock Quantity", 
    s.supplier_name AS "Supplier Name", 
    m.manufacturer_name AS "Manufacturer Name"
FROM 
    tbl_Products p
JOIN 
    tbl_Product_Discount pd ON p.product_ID = pd.product_ID
JOIN 
    tbl_Discount d ON pd.discount_ID = d.discount_ID
JOIN 
    tbl_Product_Supplier ps ON p.product_ID = ps.product_ID
JOIN 
    tbl_Supplier s ON ps.supplier_ID = s.supplier_ID
JOIN 
    tbl_Product_Manufacturer pm ON p.product_ID = pm.product_ID
JOIN 
    tbl_Manufacturer m ON pm.manufacturer_ID = m.manufacturer_ID
WHERE 
    d.amount = 0;

-- Querying the view:
SELECT * FROM view_ProductsZeroDiscount;

---------------------------------------------------------------------------------------------------------------------

--Total inventory view
CREATE VIEW view_TotalInventoryValue AS
SELECT 
    p.product_ID AS "Product ID",
    p.product_name AS "Product Name",
    p.Instock AS "Stock Quantity",
    p.unit_price AS "Unit Price",
    (p.Instock * p.unit_price) AS "Total Inventory Value"
FROM 
    tbl_Products p;

-- To view total inventory value:
SELECT * FROM view_TotalInventoryValue;

---------------------------------------------------------------------------------------------------------------------

-- View of Salesperson Details
CREATE VIEW view_SalespersonDetails AS
SELECT 
    salesperson_ID AS "Salesperson ID", 
    salesperson_name AS "Salesperson Name", 
    salesperson_phone AS "Phone Number", 
    salesperson_email AS "Email", 
    salesperson_address AS "Address"
FROM 
    tbl_Salesperson;

-- To view all details:
SELECT * FROM view_SalespersonDetails;

-- To view details of a specific salesperson by ID or name:
SELECT * FROM view_SalespersonDetails WHERE [Salesperson ID] = 1;
SELECT * FROM view_SalespersonDetails WHERE [Salesperson Name] = 'Ali Ahmed';

----------------------------------------------------------------------------------------------------------------------
