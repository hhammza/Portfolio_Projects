use db_PharmacyManagement
-------------------------------------------------------Triggers----------------------------------------------------------------
CREATE TRIGGER calculate_stock_price
ON tbl_Products
INSTEAD OF INSERT
AS
BEGIN
    INSERT INTO tbl_Products (product_name, unit_price, cost_price, Instock, stock_price, batch_number, category, manufacture_date, exp_date)
    SELECT product_name, unit_price, cost_price, Instock, unit_price * Instock AS stock_price, batch_number, category, manufacture_date, exp_date
    FROM inserted;
END;
-----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER update_stock_price
ON tbl_Products
AFTER UPDATE
AS
BEGIN
    UPDATE p
    SET p.stock_price = i.unit_price * i.Instock
    FROM tbl_Products p
    INNER JOIN inserted i ON p.product_id = i.product_id;
END;

-----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_update_product_price
ON tbl_Products
AFTER UPDATE
AS
BEGIN
    -- Check if either unit_price or cost_price has changed
    IF UPDATE(unit_price) OR UPDATE(cost_price)
    BEGIN
        -- Insert the old values into tbl_product_history
        INSERT INTO tbl_product_history (product_ID, change_date, price, cost_price)
        SELECT i.product_ID, GETDATE(), d.unit_price, d.cost_price
        FROM inserted i
        INNER JOIN deleted d ON i.product_ID = d.product_ID
        WHERE i.unit_price != d.unit_price OR i.cost_price != d.cost_price;
    END
END;

-----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_backup_product_before_delete
ON tbl_Products
AFTER DELETE
AS
BEGIN
    -- Insert the deleted product data into the backup table before actual deletion
    INSERT INTO tbl_product_backup (
        product_ID,
        product_name,
        unit_price,
        cost_price,
        Instock,
        stock_price,
        batch_number,
        category,
        manufacture_date,
        exp_date
    )
    SELECT 
        d.product_ID,
        d.product_name,
        d.unit_price,
        d.cost_price,
        d.Instock,
        d.stock_price,
        d.batch_number,
        d.category,
        d.manufacture_date,
        d.exp_date
    FROM deleted d;
END;
-----------------------------------------------------------------------------------------------------------------------------------------------------
CREATE TRIGGER trg_restore_product_after_delete
ON tbl_product_backup
AFTER DELETE
AS
BEGIN
    -- Ensure IDENTITY_INSERT is ON for tbl_products to allow restoring product_ID
    SET IDENTITY_INSERT tbl_products ON;

    -- Insert the deleted backup data back into the products table
    INSERT INTO tbl_products (
        product_ID,
        product_name,
        unit_price,
        cost_price,
        Instock,
        stock_price,
        batch_number,
        category,
        manufacture_date,
        exp_date
    )
    SELECT 
        d.product_ID,
        d.product_name,
        d.unit_price,
        d.cost_price,
        d.Instock,
        d.stock_price,
        d.batch_number,
        d.category,
        d.manufacture_date,
        d.exp_date
    FROM deleted d;

    -- Turn OFF IDENTITY_INSERT after completion
    SET IDENTITY_INSERT tbl_products OFF;
END;

--------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_backup_supplier_before_delete 
ON tbl_supplier
AFTER DELETE
AS
BEGIN
    -- Insert the deleted supplier data into the backup table before actual deletion
    INSERT INTO tbl_supplier_backup (
        supplier_ID,
        supplier_name,
        supplier_phone,
        supplier_email,
        supplier_address,
        supplier_registration_date
    )
    SELECT 
        d.supplier_ID,
        d.supplier_name,
        d.supplier_phone,
        d.supplier_email,
        d.supplier_address,
        d.supplier_registration_date
    FROM deleted d;
END;

--------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_restore_supplier_after_delete
ON tbl_supplier_backup
AFTER DELETE
AS
BEGIN
    -- Ensure IDENTITY_INSERT is ON for tbl_supplier to allow restoring supplier_ID
    SET IDENTITY_INSERT tbl_supplier ON;

    -- Insert the deleted backup data back into the supplier table
    INSERT INTO tbl_supplier (
        supplier_ID,
        supplier_name,
        supplier_phone,
        supplier_email,
        supplier_address,
        supplier_registration_date
    )
    SELECT 
        d.supplier_ID,
        d.supplier_name,
        d.supplier_phone,
        d.supplier_email,
        d.supplier_address,
        d.supplier_registration_date
    FROM deleted d;

    -- Turn OFF IDENTITY_INSERT after completion
    SET IDENTITY_INSERT tbl_supplier OFF;
END;

--------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_backup_manufacturer_before_delete 
ON tbl_manufacturer
AFTER DELETE
AS
BEGIN
    -- Insert the deleted manufacturer data into the backup table before actual deletion
    INSERT INTO tbl_manufacturer_backup (
        manufacturer_ID,
        manufacturer_name,
        manufacturer_phone,
        manufacturer_email,
        manufacturer_address
    )
    SELECT 
        d.manufacturer_ID,
        d.manufacturer_name,
        d.manufacturer_phone,
        d.manufacturer_email,
        d.manufacturer_address
    FROM deleted d;
END;

--------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_restore_manufacturer_after_delete
ON tbl_manufacturer_backup
AFTER DELETE
AS
BEGIN
    -- Ensure IDENTITY_INSERT is ON for tbl_manufacturer to allow restoring manufacturer_ID
    SET IDENTITY_INSERT tbl_manufacturer ON;

    -- Insert the deleted backup data back into the manufacturer table
    INSERT INTO tbl_manufacturer (
        manufacturer_ID,
        manufacturer_name,
        manufacturer_phone,
        manufacturer_email,
        manufacturer_address
    )
    SELECT 
        d.manufacturer_ID,
        d.manufacturer_name,
        d.manufacturer_phone,
        d.manufacturer_email,
        d.manufacturer_address
    FROM deleted d;

    -- Turn OFF IDENTITY_INSERT after completion
    SET IDENTITY_INSERT tbl_manufacturer OFF;
END;

---------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_backup_customer_before_delete 
ON tbl_customer
AFTER DELETE
AS
BEGIN
    -- Insert the deleted customer data into the backup table before actual deletion
    INSERT INTO tbl_customer_backup (
        customer_ID,
        customer_name,
        customer_phone,
        customer_email,
        customer_address
    )
    SELECT 
        d.customer_ID,
        d.customer_name,
        d.customer_phone,
        d.customer_email,
        d.customer_address
    FROM deleted d;
END;

--------------------------------------------------------------------------------------------------------------------

CREATE TRIGGER trg_restore_customer_after_delete
ON tbl_customer_backup
AFTER DELETE
AS
BEGIN
    -- Ensure IDENTITY_INSERT is ON for tbl_customer to allow restoring customer_ID
    SET IDENTITY_INSERT tbl_customer ON;

    -- Insert the deleted backup data back into the customer table
    INSERT INTO tbl_customer (
        customer_ID,
        customer_name,
        customer_phone,
        customer_email,
        customer_address
    )
    SELECT 
        d.customer_ID,
        d.customer_name,
        d.customer_phone,
        d.customer_email,
        d.customer_address
    FROM deleted d;

    -- Turn OFF IDENTITY_INSERT after completion
    SET IDENTITY_INSERT tbl_customer OFF;
END;

--------------------------------------------------------------------------------------------------------------------

