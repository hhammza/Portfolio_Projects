use db_PharmacyManagement
-----------------------------------------------------------------procedures-------------------------------------------------------------
--add new product1
CREATE PROCEDURE AddProduct
    @product_name VARCHAR(200), @unit_price FLOAT, @batch_price FLOAT, @batch_number INT, @cost_price float,
    @quantity INT, @category VARCHAR(150), @manu_date DATE, @exp_date DATE
AS
BEGIN
    BEGIN TRY
        -- Insert the new product into tbl_Products
        INSERT INTO tbl_Products (
            product_name, unit_price, stock_price, batch_number, cost_price, Instock, category, 
            manufacture_date, exp_date
        )VALUES (
            @product_name, @unit_price, @batch_price, @batch_number, @cost_price,  
            @quantity, @category, @manu_date, @exp_date
        );

        -- Success message
        PRINT 'Product added successfully.';
    END TRY
    BEGIN CATCH
        -- Error handling
        PRINT 'An error occurred while adding the product.';
        PRINT ERROR_MESSAGE();
    END CATCH
END;

drop procedure AddProduct


--------------------------------------------------------------------------------------------------------------------
create view view_product as 
select product_name, unit_price, cost_price, manufacture_date, exp_date, Instock, category from tbl_Products

select * from tbl_Products

----------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE DeleteProduct
    @product_ID INT
AS
BEGIN
    BEGIN TRY
        -- Check if the product exists
        IF NOT EXISTS (SELECT 1 FROM tbl_Products WHERE product_ID = @product_ID)
        BEGIN 
            PRINT 'Product not found.';
            RETURN;
        END;

        -- Start a transaction
        BEGIN TRANSACTION;

        -- Insert the product details into the backup table before deletion
        INSERT INTO tbl_product_backup (
            product_name, unit_price, stock_price, cost_price, batch_number, Instock, 
            category, manufacture_date,  exp_date
        )
        SELECT 
            product_name, unit_price, stock_price,cost_price, batch_number, Instock, 
            category, manufacture_date, exp_date
        FROM tbl_Products
        WHERE product_ID = @product_ID;

        -- Delete the product from the products table
        DELETE FROM tbl_Products
        WHERE product_ID = @product_ID;

        -- Commit the transaction
        COMMIT TRANSACTION;

        PRINT 'Product deleted successfully and backed up.';
    END TRY
    BEGIN CATCH
        -- Rollback the transaction in case of an error
        ROLLBACK TRANSACTION;

        PRINT 'An error occurred while deleting the product.';
        PRINT ERROR_MESSAGE();
    END CATCH
END;
---------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE SearchProductByName
    @ProductName NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    -- Search products where product_name starts with the input string
    SELECT * FROM view_product
    WHERE product_name LIKE @ProductName + '%'
END;
----------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE GetExpiringOrExpiredProducts
AS
BEGIN
    BEGIN TRY
        -- Get the current date
        DECLARE @currentDate DATE = GETDATE();

        -- Fetch products expiring in the next month or already expired
        SELECT 
            product_ID, product_name, unit_price, stock_price, category, manufacture_date, exp_date,
            DATEDIFF(DAY, @currentDate, exp_date) AS Days_To_Expiry
        FROM tbl_Products
        WHERE 
            exp_date <= DATEADD(MONTH, 1, @currentDate)
        ORDER BY exp_date;

        PRINT 'Query executed successfully.';
    END TRY
    BEGIN CATCH
        -- Handle any errors
        PRINT 'An error occurred while fetching expiring or expired products.';
        PRINT ERROR_MESSAGE();
    END CATCH
END;
EXEC GetExpiringOrExpiredProducts;

--------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE RestoreProducts
    @product_ID INT = NULL -- NULL means restore all products, specific ID to restore one
AS
BEGIN
    BEGIN TRY
        -- Start a transaction
        BEGIN TRANSACTION;

        -- Check if restoring a single product
        IF @product_ID IS NOT NULL
        BEGIN
            -- Check if the product exists in the backup table
            IF NOT EXISTS (SELECT 1 FROM tbl_product_backup WHERE product_ID = @product_ID)
            BEGIN
                PRINT 'Product not found in backup.';
                ROLLBACK TRANSACTION;
                RETURN;
            END;

            -- Insert the product from backup to products table
            INSERT INTO tbl_Products (
                product_name, unit_price,cost_price, stock_price, batch_number, 
                Instock, category, manufacture_date, exp_date
            )
            SELECT 
                product_name, unit_price,cost_price, stock_price, batch_number, Instock, 
                category, manufacture_date, exp_date
            FROM tbl_product_backup
            WHERE product_ID = @product_ID;

            -- Optionally delete the restored product from the backup table
            DELETE FROM tbl_product_backup WHERE product_ID = @product_ID;

            PRINT 'Product restored successfully.';
        END
        ELSE
        BEGIN
            -- Restore all products from backup table
            INSERT INTO tbl_Products (
                product_name, unit_price,cost_price, stock_price, batch_number, Instock, 
                category, manufacture_date, exp_date
            )
            SELECT 
                product_name, unit_price,cost_price, stock_price, batch_number, 
                Instock, category, manufacture_date, exp_date
            FROM tbl_product_backup;

            -- Optionally delete all products from the backup table after restoration
            DELETE FROM tbl_product_backup;

            PRINT 'All products restored successfully.';
        END;

        -- Commit the transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Rollback the transaction in case of error
        ROLLBACK TRANSACTION;

        PRINT 'An error occurred while restoring products.';
        PRINT ERROR_MESSAGE();
    END CATCH
END;

EXEC RestoreProducts @product_ID = 19;

----------------------------------------------------------------------------------------------------------------------
--GenerateWeeklySalesReport
CREATE PROCEDURE GenerateWeeklySalesReport
AS
BEGIN
    -- Declare variables for date range
    DECLARE @StartDate DATE = DATEADD(DAY, -7, GETDATE());
    DECLARE @EndDate DATE = CAST(GETDATE() AS DATE);
    
    -- Select sales data for the past week
    SELECT 
        o.order_ID,
        c.customer_name,
        c.customer_phone,
        p.product_name,
        o.quantity,  -- Quantity is in tbl_orders
        p.unit_price,
        (o.quantity * p.unit_price) AS total_price,
        o.discount,
        (o.quantity * p.unit_price) - o.discount AS final_price,
        o.payment_method,
        o.order_date
    FROM tbl_orders o
    INNER JOIN tbl_orderLine ol ON o.order_ID = ol.order_ID
    INNER JOIN tbl_products p ON ol.product_ID = p.product_ID
    INNER JOIN tbl_customer c ON o.customer_ID = c.customer_ID
    WHERE o.order_date BETWEEN @StartDate AND @EndDate
    ORDER BY o.order_date ASC, o.order_ID ASC;
END;
-------------------------------------------------------------------------------------------------------------------
--low stock products
CREATE PROCEDURE GetLowStockProducts
AS
BEGIN
    -- Retrieve products with stock less than 50
    SELECT 
        product_ID,
        product_name,
        Instock,
        category,
        stock_price
    FROM tbl_products
    WHERE Instock < 50
    ORDER BY Instock ASC; -- Sort by stock levels in ascending order for better visualization
END;

-------------------------------------------------------------------------------------------------------------------

--CalculateTotalBillAmount
CREATE PROCEDURE CalculateTotalBillAmount
    @OrderID INT
AS
BEGIN
    -- Declare a variable to hold the total amount
    DECLARE @TotalAmount DECIMAL(10, 2);

    -- Calculate the total amount for the given order
    SELECT 
        @TotalAmount = SUM(o.quantity * p.unit_price - ISNULL(o.discount, 0))
    FROM tbl_orderLine ol
    INNER JOIN tbl_products p ON ol.product_ID = p.product_ID
    INNER JOIN tbl_orders o ON ol.order_ID = o.order_ID
    WHERE ol.order_ID = @OrderID;

    -- Return the total amount
    SELECT 
        @OrderID AS OrderID,
        @TotalAmount AS TotalBillAmount;
END;
------------------------------------------------------------------------------------------------------------------

--CalculateDiscount
CREATE PROCEDURE CalculateDiscount
    @ProductID INT,
    @DiscountPercentage DECIMAL(5, 2) -- Percentage discount (e.g., 10.00 for 10%)
AS
BEGIN
    -- Declare a variable to store the discount amount
    DECLARE @DiscountAmount DECIMAL(10, 2);

    -- Calculate the discount amount
    SELECT 
        @DiscountAmount = (unit_price * @DiscountPercentage / 100)
    FROM tbl_products
    WHERE product_ID = @ProductID;

    -- Return the discount amount
    SELECT 
        @ProductID AS ProductID,
        @DiscountPercentage AS DiscountPercentage,
        @DiscountAmount AS DiscountAmount;
END;

-------------------------------------------------------------------------------------------------------------------