from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QSpacerItem, QSizePolicy, QComboBox,
    QDateEdit
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QDate
from DBconnectivity import DatabaseConnection

class AddProduct(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Add New Medicine to Inventory")
        self.setGeometry(100, 100, 500, 600)

        # Set background color to match the main class
        self.setStyleSheet("background-color: #ecf0f1;")

        # Main Layout (Vertical layout)
        main_layout = QVBoxLayout()

        # Medicine Name
        main_layout.addWidget(QLabel("Medicine Name:"))
        self.medicine_name = QLineEdit()
        main_layout.addWidget(self.medicine_name)

        # Date Fields
        date_layout = QHBoxLayout()
        date_layout.addWidget(QLabel("Manufacture Date:"))
        self.manu_date = QDateEdit()
        self.manu_date.setCalendarPopup(True)  # Enable calendar popup
        self.manu_date.setDate(QDate.currentDate())  # Default to current date
        date_layout.addWidget(self.manu_date)

        date_layout.addWidget(QLabel("Expiration Date:"))
        self.exp_date = QDateEdit()
        self.exp_date.setCalendarPopup(True)
        self.exp_date.setDate(QDate.currentDate())
        date_layout.addWidget(self.exp_date)

        main_layout.addLayout(date_layout)

        # Quantity, Prices, and Batch Number
        for label, attribute in [
            ("Stock:", "quantity"),
            ("Unit Price:", "unit_price"),
            ("Cost Price:", "cost_price"),
            ("Batch Price:", "batch_price"),
            ("Batch Number:", "batch_number"),
        ]:
            main_layout.addWidget(QLabel(label))
            setattr(self, attribute, QLineEdit())
            main_layout.addWidget(getattr(self, attribute))

        # Category ComboBox
        main_layout.addWidget(QLabel("Category of Medicine:"))
        self.combo_box = QComboBox()
        self.combo_box.addItems(["Medicines", "Medical Equipment", "Supplements", "Personal Care", "Personal Protective Equipment"])
        main_layout.addWidget(self.combo_box)

        main_layout.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Buttons
        button_layout = QHBoxLayout()

        # Close Button
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet(self.button_style())  # Apply button style
        close_btn.clicked.connect(self.close)
        button_layout.addWidget(close_btn)

        # Add Button
        add_btn = QPushButton("ADD")
        add_btn.setStyleSheet(self.button_style(active=True))  # Active button style
        add_btn.clicked.connect(self.submit_details)
        button_layout.addWidget(add_btn)

        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def button_style(self, active=False):
        """Dynamic button style for active and inactive states"""
        if active:
            return """
                QPushButton {
                    background-color: #16a085;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #1abc9c;
                }
            """
        else:
            return """
                QPushButton {
                    background-color: #34495e;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #2c3e50;
                }
            """

    def submit_details(self):
        try:
            # Retrieve input data
            med_name = self.medicine_name.text().strip()
            manufac_date = self.manu_date.date().toString("yyyy-MM-dd")
            expir_date = self.exp_date.date().toString("yyyy-MM-dd")
            quant = self.quantity.text().strip()
            unit_price = self.unit_price.text().strip()
            cost_price = self.cost_price.text().strip()

            batch_number = self.batch_number.text().strip()
            categ = self.combo_box.currentText()

            # Validate inputs
            if not all([med_name, manufac_date, expir_date, quant, unit_price, cost_price, batch_number, categ]):
                QMessageBox.warning(self, "Input Error", "Please fill in all fields!")
                return

            # Convert values to appropriate data types
            quant = int(quant)
            unit_price = float(unit_price)
            cost_price = float(cost_price)

            batch_number = int(batch_number)

            # Database operation
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()
            cursor.execute("""
                EXEC AddProduct 
                    @product_name = ?, @unit_price = ?, @cost_price = ?, @batch_number = ?, 
                    @quantity = ?,  @category = ?, @manu_date = ?, @exp_date = ?
            """, (
                med_name, unit_price, cost_price, batch_number, quant, categ, manufac_date, expir_date
            ))
            connection.commit()
            QMessageBox.information(self, "Success", "Product added successfully!")

            # Clear inputs
            self.medicine_name.clear()
            self.manu_date.setDate(QDate.currentDate())
            self.exp_date.setDate(QDate.currentDate())
            self.quantity.clear()
            self.unit_price.clear()
            self.cost_price.clear()

            self.batch_number.clear()
            self.combo_box.setCurrentIndex(0)
        except ValueError:
            QMessageBox.critical(self, "Input Error", "Please enter valid numbers!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {e}")
            print("Error:", e)