import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QMessageBox, QSizePolicy, QHeaderView
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from AddCustomer import AddCustomer
from DBconnectivity import DatabaseConnection
from UpdateCustomer import UpdateCustomer
from DeletCustomer import DeleteCustomer


'''
class CustomerPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback

        self.add_customer_widget = AddCustomer()
        self.add_customer_widget.customer_added.connect(self.insert_data)
        
        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Customer:")
        search_input = QLineEdit()
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.customer_table = QTableWidget()
        self.customer_table.setRowCount(1000)
        self.customer_table.setColumnCount(5)
        self.customer_table.setHorizontalHeaderLabels(["Customer ID", "Customer Name", "Phone", "Email", "Address"])
        main_layout.addWidget(self.customer_table)

        self.insert_data()

        # Buttons Section
        buttons_layout = QHBoxLayout()
        self.add_button = QPushButton("Add Customer")
        self.add_button.clicked.connect(self.show_addCustomer)
        self.update_button = QPushButton("Update Customer")
        self.update_button.clicked.connect(self.show_updateCustomer)
        self.delete_button = QPushButton("Delete Customer")
        self.delete_button.clicked.connect(self.show_deleteCustomer)
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(self.add_button)
        buttons_layout.addWidget(self.update_button)
        buttons_layout.addWidget(self.delete_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by FHH | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        exit_button.clicked.connect(self.close)

        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()
        try:
            query = "select * from tbl_Customer"

            cursor.execute(query)
            data = cursor.fetchall()

            # Set the row count
            self.customer_table.setRowCount(len(data))

            # Populate the table with the data
            for row_index, row_data in enumerate(data):
                for col_index, value in enumerate(row_data):
                    self.customer_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error fetching data: {e}")

        finally:
            cursor.close()

    def search_medicine(self):
        # Placeholder for search logic
        print("Search functionality triggered!")

    def show_addCustomer(self):
        self.customers = AddCustomer()
        self.customers.customer_added.connect(self.insert_data)
        self.customers.show()
    def show_updateCustomer(self):
        self.customers = UpdateCustomer()
        self.customers.customer_updated.connect(self.insert_data)
        self.customers.show()

    def show_deleteCustomer(self):
        self.customers = DeleteCustomer(self.customer_table)
        self.customers.show()'''
class CustomerPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback

        self.add_customer_widget = AddCustomer()
        self.add_customer_widget.customer_added.connect(self.insert_data)

        # Main layout container
        main_layout = QVBoxLayout()

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Customer:")
        search_label.setStyleSheet("color: #005A8D; font-weight: bold;")
        search_input = QLineEdit()
        search_input.setStyleSheet("background-color: #FFFFFF; border: 1px solid #A0C4FF; border-radius: 5px;")
        search_button = QPushButton("Search")
        search_button.setStyleSheet(
            "background-color: #4CAF50; color: white; font-weight: bold; border-radius: 5px; padding: 5px;"
        )
        search_layout.addWidget(search_label)
        search_layout.addWidget(search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying customers
        self.customer_table = QTableWidget()
        self.customer_table.setRowCount(1000)
        self.customer_table.setColumnCount(5)
        self.customer_table.setHorizontalHeaderLabels(["Customer ID", "Customer Name", "Phone", "Email", "Address"])

        # Style for the Table Header
        self.customer_table.horizontalHeader().setStyleSheet("""
            QHeaderView::section {
                background-color: #005A8D;
                color: white;
                padding: 5px;
                font-weight: bold;
            }
        """)
        self.customer_table.setStyleSheet("alternate-background-color: #F2F2F2; background-color: white;")
        self.customer_table.setAlternatingRowColors(True)

        # Resize policies for the table
        self.customer_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.customer_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.customer_table.setMinimumHeight(400)  # Ensure it takes a reasonable height
        main_layout.addWidget(self.customer_table)

        # Load initial data
        self.insert_data()

        # Buttons Section
        buttons_layout = QHBoxLayout()
        button_style = "background-color: #005A8D; color: white; font-weight: bold; border-radius: 5px; padding: 5px;"
        self.add_button = QPushButton("Add Customer")
        self.add_button.setStyleSheet(button_style)
        self.add_button.clicked.connect(self.show_addCustomer)

        self.update_button = QPushButton("Update Customer")
        self.update_button.setStyleSheet(button_style)
        self.update_button.clicked.connect(self.show_updateCustomer)

        self.delete_button = QPushButton("Delete Customer")
        self.delete_button.setStyleSheet(button_style)
        self.delete_button.clicked.connect(self.show_deleteCustomer)

        exit_button = QPushButton("Exit")
        exit_button.setStyleSheet("background-color: #005A8D; color: white; font-weight: bold; border-radius: 5px; padding: 5px;")
        exit_button.clicked.connect(self.close)

        buttons_layout.addWidget(self.add_button)
        buttons_layout.addWidget(self.update_button)
        buttons_layout.addWidget(self.delete_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by FHH | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: #808080; background-color: #F7F7F7; padding: 5px; border-radius: 5px;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        exit_button.clicked.connect(self.close)

        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()
        try:
            query = "select * from tbl_Customer"

            cursor.execute(query)
            data = cursor.fetchall()

            # Set the row count
            self.customer_table.setRowCount(len(data))

            # Populate the table with the data
            for row_index, row_data in enumerate(data):
                for col_index, value in enumerate(row_data):
                    self.customer_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error fetching data: {e}")

        finally:
            cursor.close()

    def search_medicine(self):
        # Placeholder for search logic
        print("Search functionality triggered!")

    def show_addCustomer(self):
        self.customers = AddCustomer()
        self.customers.customer_added.connect(self.insert_data)
        self.customers.show()

    def show_updateCustomer(self):
        self.customers = UpdateCustomer()
        self.customers.customer_updated.connect(self.insert_data)
        self.customers.show()

    def show_deleteCustomer(self):
        self.customers = DeleteCustomer(self.customer_table)
        self.customers.show()
