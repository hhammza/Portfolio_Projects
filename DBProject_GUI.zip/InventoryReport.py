'''import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton
from PyQt5.QtCore import Qt

class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: white;")

        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(4)  # Four columns
        self.table.setHorizontalHeaderLabels(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Insert the data
        self.insert_data()

        # Create a button to close the window (optional)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        main_layout.addWidget(close_button)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        data = [
            ('Medicines', 'Tablets', 'Pain Relief', 'Hilton Pharma'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Searle Pakistan'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Antibiotics', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Pain Relief', 'GlaxoSmithKline'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Medisave Pvt Ltd'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Crown Pharmaceuticals'),
            ('Medicines', 'Tablets', 'Antidiarrheal', 'Maple Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'Monitoring Devices', 'Hilton Pharma'),
            ('Medical Equipment', 'Surgical Tools', 'Minor Procedures', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Blood Pressure Monitoring', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Sutures & Staplers', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Masks', 'Face Protection', 'GlaxoSmithKline'),
            ('Personal Protective Equipment', 'Sanitizers', 'Hand Hygiene', 'Macter International'),
            ('Personal Protective Equipment', 'Face Shields', 'Face Protection', 'Maple Pharma'),
            ('Supplements', 'Multivitamins', 'General Health', 'Novartis Pharma'),
            ('Supplements', 'Energy Drinks', 'Nutrition', 'Abbott Pakistan'),
            ('Supplements', 'Proteins', 'Body Building', 'Sanofi Aventis'),
            ('Personal Care', 'Hair Care', 'Shampoos', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Moisturizers', 'Hilton Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'X-ray Machines', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Orthopedic Tools', 'Crown Pharmaceuticals'),
            ('Medicines', 'Inhalers', 'Respiratory Care', 'Sanofi Aventis'),
            ('Medicines', 'Patches', 'Pain Relief', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Gloves', 'Hand Protection', 'Hilton Pharma'),
            ('Medicines', 'Injections', 'Vaccines', 'GlaxoSmithKline'),
            ('Medicines', 'Tablets', 'Heart Health', 'Macter International'),
            ('Medical Equipment', 'Diagnostic Tools', 'ECG Machines', 'Maple Pharma'),
            ('Medicines', 'Oral Liquids', 'Digestive Health', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Scalpels', 'Searle Pakistan'),
            ('Supplements', 'Vitamins', 'Immunity Boosters', 'Sanofi Aventis'),
            ('Medicines', 'Tablets', 'Allergy Relief', 'Macter International'),
            ('Medical Equipment', 'Thermometers', 'Body Temperature Monitoring', 'Hilton Pharma'),
            ('Medicines', 'Capsules', 'Pain Relief', 'Abbott Pakistan'),
            ('Supplements', 'Minerals', 'Bone Health', 'Novartis Pharma'),
            ('Personal Care', 'Hair Care', 'Conditioners', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Sunscreens', 'GlaxoSmithKline'),
            ('Medicines', 'Pills', 'Womens Health', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Bone Surgery', 'Crown Pharmaceuticals'),
            ('Medicines', 'Creams', 'Topical Treatments', 'Macter International'),
            ('Personal Protective Equipment', 'Boots', 'Foot Protection', 'Abbott Pakistan'),
            ('Supplements', 'Herbal Products', 'Natural Remedies', 'Maple Pharma'),
            ('Medicines', 'Vitamins', 'Fatigue Relief', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Dental Care', 'Toothpastes', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Cholesterol Control', 'Hilton Pharma'),
            ('Supplements', 'Energy Bars', 'Nutrition', 'Searle Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Dental Equipment', 'Abbott Pakistan'),
            ('Personal Care', 'Foot Care', 'Creams & Lotions', 'Novartis Pharma'),
            ('Medicines', 'Ointments', 'Skin Treatments', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Immunity Boosters', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Ophthalmic Instruments', 'Maple Pharma'),
            ('Medicines', 'Syrups', 'Antipyretics', 'Macter International'),
            ('Supplements', 'Herbal Tea', 'Stress Relief', 'Sanofi Aventis')
        ]

        # Set the row count
        self.table.setRowCount(len(data))

        # Populate the table with the data
        for row, (stock_category, stock_group, category_group, manufacturer) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(stock_category))
            self.table.setItem(row, 1, QTableWidgetItem(stock_group))
            self.table.setItem(row, 2, QTableWidgetItem(category_group))
            self.table.setItem(row, 3, QTableWidgetItem(manufacturer))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryTable()
    window.show()
    sys.exit(app.exec_())'''
from PyQt5 import QtWidgets

'''import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor

class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(600, 200, 800, 600)
        self.setStyleSheet("background-color: lightblue;")  # Set background color to light blue

        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        self.table.setStyleSheet(
            """
            QTableWidget::item { background-color: lightblue; } 
            QTableWidget::item:selected { background-color: darkblue; color: white; }
            QHeaderView::section { background-color: darkblue; color: white; font-weight: bold; }
            """
        )
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(4)  # Four columns
        self.table.setHorizontalHeaderLabels(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Set column widths
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 150)

        # Insert the data
        self.insert_data()

        # Create a button to close the window (optional)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        main_layout.addWidget(close_button)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        data = [
            ('Medicines', 'Tablets', 'Pain Relief', 'Hilton Pharma'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Searle Pakistan'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Antibiotics', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Pain Relief', 'GlaxoSmithKline'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Medisave Pvt Ltd'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Crown Pharmaceuticals'),
            ('Medicines', 'Tablets', 'Antidiarrheal', 'Maple Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'Monitoring Devices', 'Hilton Pharma'),
            ('Medical Equipment', 'Surgical Tools', 'Minor Procedures', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Blood Pressure Monitoring', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Sutures & Staplers', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Masks', 'Face Protection', 'GlaxoSmithKline'),
            ('Personal Protective Equipment', 'Sanitizers', 'Hand Hygiene', 'Macter International'),
            ('Personal Protective Equipment', 'Face Shields', 'Face Protection', 'Maple Pharma'),
            ('Supplements', 'Multivitamins', 'General Health', 'Novartis Pharma'),
            ('Supplements', 'Energy Drinks', 'Nutrition', 'Abbott Pakistan'),
            ('Supplements', 'Proteins', 'Body Building', 'Sanofi Aventis'),
            ('Personal Care', 'Hair Care', 'Shampoos', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Moisturizers', 'Hilton Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'X-ray Machines', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Orthopedic Tools', 'Crown Pharmaceuticals'),
            ('Medicines', 'Inhalers', 'Respiratory Care', 'Sanofi Aventis'),
            ('Medicines', 'Patches', 'Pain Relief', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Gloves', 'Hand Protection', 'Hilton Pharma'),
            ('Medicines', 'Injections', 'Vaccines', 'GlaxoSmithKline'),
            ('Medicines', 'Tablets', 'Heart Health', 'Macter International'),
            ('Medical Equipment', 'Diagnostic Tools', 'ECG Machines', 'Maple Pharma'),
            ('Medicines', 'Oral Liquids', 'Digestive Health', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Scalpels', 'Searle Pakistan'),
            ('Supplements', 'Vitamins', 'Immunity Boosters', 'Sanofi Aventis'),
            ('Medicines', 'Tablets', 'Allergy Relief', 'Macter International'),
            ('Medical Equipment', 'Thermometers', 'Body Temperature Monitoring', 'Hilton Pharma'),
            ('Medicines', 'Capsules', 'Pain Relief', 'Abbott Pakistan'),
            ('Supplements', 'Minerals', 'Bone Health', 'Novartis Pharma'),
            ('Personal Care', 'Hair Care', 'Conditioners', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Sunscreens', 'GlaxoSmithKline'),
            ('Medicines', 'Pills', 'Womens Health', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Bone Surgery', 'Crown Pharmaceuticals'),
            ('Medicines', 'Creams', 'Topical Treatments', 'Macter International'),
            ('Personal Protective Equipment', 'Boots', 'Foot Protection', 'Abbott Pakistan'),
            ('Supplements', 'Herbal Products', 'Natural Remedies', 'Maple Pharma'),
            ('Medicines', 'Vitamins', 'Fatigue Relief', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Dental Care', 'Toothpastes', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Cholesterol Control', 'Hilton Pharma'),
            ('Supplements', 'Energy Bars', 'Nutrition', 'Searle Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Dental Equipment', 'Abbott Pakistan'),
            ('Personal Care', 'Foot Care', 'Creams & Lotions', 'Novartis Pharma'),
            ('Medicines', 'Ointments', 'Skin Treatments', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Immunity Boosters', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Ophthalmic Instruments', 'Maple Pharma'),
            ('Medicines', 'Syrups', 'Antipyretics', 'Macter International'),
            ('Supplements', 'Herbal Tea', 'Stress Relief', 'Sanofi Aventis'),
        ]

        self.table.setRowCount(len(data))

        for row, (stock_category, stock_group, category_group, manufacturer) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(stock_category))
            self.table.setItem(row, 1, QTableWidgetItem(stock_group))
            self.table.setItem(row, 2, QTableWidgetItem(category_group))
            self.table.setItem(row, 3, QTableWidgetItem(manufacturer))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryTable()
    window.show()
    sys.exit(app.exec_())'''
'''import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QMessageBox
)
from PyQt5.QtCore import Qt


class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(600, 200, 800, 600)
        self.setStyleSheet("background-color: lightblue;")  # Set background color to light blue

        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        self.table.setStyleSheet(
            """
            QTableWidget::item { background-color: lightblue; } 
            QTableWidget::item:selected { background-color: darkblue; color: white; }
            QHeaderView::section { background-color: darkblue; color: white; font-weight: bold; }
            """
        )
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(4)  # Four columns
        self.table.setHorizontalHeaderLabels(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Set column widths
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 150)

        # Insert the data
        self.insert_data()

        # Create buttons
        report_button = QPushButton("Generate Report")
        report_button.clicked.connect(self.generate_report)
        main_layout.addWidget(report_button)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        main_layout.addWidget(close_button)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data for the table
        data = [
            ('Medicines', 'Tablets', 'Pain Relief', 'Hilton Pharma'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Searle Pakistan'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Antibiotics', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Pain Relief', 'GlaxoSmithKline'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Medisave Pvt Ltd'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Crown Pharmaceuticals'),
            ('Medicines', 'Tablets', 'Antidiarrheal', 'Maple Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'Monitoring Devices', 'Hilton Pharma'),
            ('Medical Equipment', 'Surgical Tools', 'Minor Procedures', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Blood Pressure Monitoring', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Sutures & Staplers', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Masks', 'Face Protection', 'GlaxoSmithKline'),
            ('Personal Protective Equipment', 'Sanitizers', 'Hand Hygiene', 'Macter International'),
            ('Personal Protective Equipment', 'Face Shields', 'Face Protection', 'Maple Pharma'),
            ('Supplements', 'Multivitamins', 'General Health', 'Novartis Pharma'),
            ('Supplements', 'Energy Drinks', 'Nutrition', 'Abbott Pakistan'),
            ('Supplements', 'Proteins', 'Body Building', 'Sanofi Aventis'),
            ('Personal Care', 'Hair Care', 'Shampoos', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Moisturizers', 'Hilton Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'X-ray Machines', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Orthopedic Tools', 'Crown Pharmaceuticals'),
            ('Medicines', 'Inhalers', 'Respiratory Care', 'Sanofi Aventis'),
            ('Medicines', 'Patches', 'Pain Relief', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Gloves', 'Hand Protection', 'Hilton Pharma'),
            ('Medicines', 'Injections', 'Vaccines', 'GlaxoSmithKline'),
            ('Medicines', 'Tablets', 'Heart Health', 'Macter International'),
            ('Medical Equipment', 'Diagnostic Tools', 'ECG Machines', 'Maple Pharma'),
            ('Medicines', 'Oral Liquids', 'Digestive Health', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Scalpels', 'Searle Pakistan'),
            ('Supplements', 'Vitamins', 'Immunity Boosters', 'Sanofi Aventis'),
            ('Medicines', 'Tablets', 'Allergy Relief', 'Macter International'),
            ('Medical Equipment', 'Thermometers', 'Body Temperature Monitoring', 'Hilton Pharma'),
            ('Medicines', 'Capsules', 'Pain Relief', 'Abbott Pakistan'),
            ('Supplements', 'Minerals', 'Bone Health', 'Novartis Pharma'),
            ('Personal Care', 'Hair Care', 'Conditioners', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Sunscreens', 'GlaxoSmithKline'),
            ('Medicines', 'Pills', 'Womens Health', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Bone Surgery', 'Crown Pharmaceuticals'),
            ('Medicines', 'Creams', 'Topical Treatments', 'Macter International'),
            ('Personal Protective Equipment', 'Boots', 'Foot Protection', 'Abbott Pakistan'),
            ('Supplements', 'Herbal Products', 'Natural Remedies', 'Maple Pharma'),
            ('Medicines', 'Vitamins', 'Fatigue Relief', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Dental Care', 'Toothpastes', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Cholesterol Control', 'Hilton Pharma'),
            ('Supplements', 'Energy Bars', 'Nutrition', 'Searle Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Dental Equipment', 'Abbott Pakistan'),
            ('Personal Care', 'Foot Care', 'Creams & Lotions', 'Novartis Pharma'),
            ('Medicines', 'Ointments', 'Skin Treatments', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Immunity Boosters', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Ophthalmic Instruments', 'Maple Pharma'),
            ('Medicines', 'Syrups', 'Antipyretics', 'Macter International'),
            ('Supplements', 'Herbal Tea', 'Stress Relief', 'Sanofi Aventis'),

        ]

        # Set the row count
        self.table.setRowCount(len(data))

        # Populate the table with the data
        for row, (stock_category, stock_group, category_group, manufacturer) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(stock_category))
            self.table.setItem(row, 1, QTableWidgetItem(stock_group))
            self.table.setItem(row, 2, QTableWidgetItem(category_group))
            self.table.setItem(row, 3, QTableWidgetItem(manufacturer))

    def generate_report(self):
        selected_items = self.table.selectedItems()

        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select one or more rows.")
            return

        # Group selected items into rows
        selected_rows = {}
        for item in selected_items:
            row = item.row()
            if row not in selected_rows:
                selected_rows[row] = []
            selected_rows[row].append(item.text())

        # Format the report
        report_lines = ["Stock Category | Stock Group | Category Group | Manufacturer"]
        for row_data in selected_rows.values():
            report_lines.append(" | ".join(row_data))

        # Display the report in a message box
        report_text = "\n".join(report_lines)
        QMessageBox.information(self, "Selected Items Report", report_text)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryTable()
    window.show()
    sys.exit(app.exec_())'''
'''import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, \
    QFileDialog, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor

class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(600, 200, 800, 600)
        self.setStyleSheet("background-color: lightblue;")  # Set background color to light blue



        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        self.table.setStyleSheet(
            """
            QTableWidget::item { background-color: lightblue; } 
            QTableWidget::item:selected { background-color: darkblue; color: white; }
            QHeaderView::section { background-color: darkblue; color: white; font-weight: bold; }
            """
        )
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(4)  # Four columns
        self.table.setHorizontalHeaderLabels(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Set column widths
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 150)

        # Insert the data
        self.insert_data()

        self.reportButton = QtWidgets.QPushButton("Generate Report", self)
        self.reportButton.setGeometry(50, 500, 200, 40)
        self.reportButton.clicked.connect(self.generate_report)

        # Create a button to close the window (optional)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        main_layout.addWidget(self.reportButton)
        main_layout.addWidget(close_button)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        data = [
            ('Medicines', 'Tablets', 'Pain Relief', 'Hilton Pharma'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Searle Pakistan'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Sanofi Aventis'),
            ('Medicines', 'Capsules', 'Antibiotics', 'Abbott Pakistan'),
            ('Medicines', 'Tablets', 'Pain Relief', 'GlaxoSmithKline'),
            ('Medicines', 'Syrups', 'Cough & Cold', 'Medisave Pvt Ltd'),
            ('Medicines', 'Injections', 'Diabetes Care', 'Crown Pharmaceuticals'),
            ('Medicines', 'Tablets', 'Antidiarrheal', 'Maple Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'Monitoring Devices', 'Hilton Pharma'),
            ('Medical Equipment', 'Surgical Tools', 'Minor Procedures', 'Searle Pakistan'),
            ('Medical Equipment', 'Diagnostic Tools', 'Blood Pressure Monitoring', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Sutures & Staplers', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Masks', 'Face Protection', 'GlaxoSmithKline'),
            ('Personal Protective Equipment', 'Sanitizers', 'Hand Hygiene', 'Macter International'),
            ('Personal Protective Equipment', 'Face Shields', 'Face Protection', 'Maple Pharma'),
            ('Supplements', 'Multivitamins', 'General Health', 'Novartis Pharma'),
            ('Supplements', 'Energy Drinks', 'Nutrition', 'Abbott Pakistan'),
            ('Supplements', 'Proteins', 'Body Building', 'Sanofi Aventis'),
            ('Personal Care', 'Hair Care', 'Shampoos', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Moisturizers', 'Hilton Pharma'),
            ('Medical Equipment', 'Diagnostic Tools', 'X-ray Machines', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Orthopedic Tools', 'Crown Pharmaceuticals'),
            ('Medicines', 'Inhalers', 'Respiratory Care', 'Sanofi Aventis'),
            ('Medicines', 'Patches', 'Pain Relief', 'Abbott Pakistan'),
            ('Personal Protective Equipment', 'Gloves', 'Hand Protection', 'Hilton Pharma'),
            ('Medicines', 'Injections', 'Vaccines', 'GlaxoSmithKline'),
            ('Medicines', 'Tablets', 'Heart Health', 'Macter International'),
            ('Medical Equipment', 'Diagnostic Tools', 'ECG Machines', 'Maple Pharma'),
            ('Medicines', 'Oral Liquids', 'Digestive Health', 'Abbott Pakistan'),
            ('Medical Equipment', 'Surgical Tools', 'Scalpels', 'Searle Pakistan'),
            ('Supplements', 'Vitamins', 'Immunity Boosters', 'Sanofi Aventis'),
            ('Medicines', 'Tablets', 'Allergy Relief', 'Macter International'),
            ('Medical Equipment', 'Thermometers', 'Body Temperature Monitoring', 'Hilton Pharma'),
            ('Medicines', 'Capsules', 'Pain Relief', 'Abbott Pakistan'),
            ('Supplements', 'Minerals', 'Bone Health', 'Novartis Pharma'),
            ('Personal Care', 'Hair Care', 'Conditioners', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Skin Care', 'Sunscreens', 'GlaxoSmithKline'),
            ('Medicines', 'Pills', 'Womens Health', 'Sanofi Aventis'),
            ('Medical Equipment', 'Surgical Tools', 'Bone Surgery', 'Crown Pharmaceuticals'),
            ('Medicines', 'Creams', 'Topical Treatments', 'Macter International'),
            ('Personal Protective Equipment', 'Boots', 'Foot Protection', 'Abbott Pakistan'),
            ('Supplements', 'Herbal Products', 'Natural Remedies', 'Maple Pharma'),
            ('Medicines', 'Vitamins', 'Fatigue Relief', 'Medisave Pvt Ltd'),
            ('Personal Care', 'Dental Care', 'Toothpastes', 'Abbott Pakistan'),
        ]

        # Set the row count
        self.table.setRowCount(len(data))

        # Populate the table with the data
        for row, (stock_category, stock_group, category_group, manufacturer) in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(stock_category))
            self.table.setItem(row, 1, QTableWidgetItem(stock_group))
            self.table.setItem(row, 2, QTableWidgetItem(category_group))
            self.table.setItem(row, 3, QTableWidgetItem(manufacturer))

    def generate_report(self):
        # Get table data
        data = []
        for row in range(self.table.rowCount()):
            data_row = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item:
                    data_row.append(item.text())
                else:
                    data_row.append("")
            data.append(data_row)

        # Save data to Excel (using openpyxl)
        import openpyxl

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])
        for row in data:
            ws.append(row)
        filename, _ = QFileDialog.getSaveFileName(self, "Save Report", "", "*.xlsx")
        if filename:
            wb.save(filename)
            QMessageBox.information(self, "Success", "Report saved successfully!")
        else:
            QMessageBox.warning(self, "Error", "No file selected!")
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryTable()
    window.show()
    sys.exit(app.exec_())'''

import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, \
    QFileDialog, QMessageBox
from DBconnectivity import DatabaseConnection
'''

class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(600, 200, 800, 600)
        self.setStyleSheet("background-color: lightblue;")  # Set background color to light blue

        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        self.table.setStyleSheet(
            """
            QTableWidget::item { background-color: lightblue; } 
            QTableWidget::item:selected { background-color: darkblue; color: white; }
            QHeaderView::section { background-color: darkblue; color: white; font-weight: bold; }
            """
        )
        self.table.setSelectionMode(QTableWidget.MultiSelection)  # Allow multi-row selection
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(5)  # Four columns
        self.table.setHorizontalHeaderLabels(["Stock ID","Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Set column widths
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 150)
        self.table.setColumnWidth(4, 150)

        # Insert the data
        self.insert_data()

        # Generate report button
        self.reportButton = QPushButton("Generate Report", self)
        self.reportButton.setGeometry(50, 500, 200, 40)
        self.reportButton.clicked.connect(self.generate_report)

        # Create a button to close the window (optional)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        main_layout.addWidget(self.reportButton)
        main_layout.addWidget(close_button)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL INSERT statement
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()
        try:
            query = "select * from tbl_ReportInventory"

            cursor.execute(query)
            data = cursor.fetchall()

        # Set the row count
            self.table.setRowCount(len(data))

        # Populate the table with the data
            for row_index, row_data in enumerate(data):
                for col_index, value in enumerate(row_data):
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error fetching data: {e}")

        finally:
            cursor.close()

    def generate_report(self):
        # Get selected rows
        selected_rows = self.table.selectionModel().selectedRows()

        # If no rows are selected, show a warning
        if not selected_rows:
            QMessageBox.warning(self, "Error", "No rows selected!")
            return

        # Prepare data for the selected rows
        data = []
        for index in selected_rows:
            row = index.row()
            data_row = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item:
                    data_row.append(item.text())
                else:
                    data_row.append("")
            data.append(data_row)

        # Save selected data to Excel (using openpyxl)
        import openpyxl

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Stock Category", "Stock Group", "Category Group", "Manufacturer"])
        for row in data:
            ws.append(row)

        filename, _ = QFileDialog.getSaveFileName(self, "Save Report", "", "*.xlsx")
        if filename:
            wb.save(filename)
            QMessageBox.information(self, "Success", "Report saved successfully!")
        else:
            QMessageBox.warning(self, "Error", "No file selected!")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryTable()
    window.show()
    sys.exit(app.exec_())'''

from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, \
    QFileDialog, QMessageBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from DBconnectivity import DatabaseConnection
import openpyxl


class InventoryTable(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventory Report")
        self.setGeometry(600, 200, 800, 600)
        self.setStyleSheet("background-color: #ecf0f1;")  # Soft gray background to match MainWindow

        # Create the layout
        main_layout = QVBoxLayout()

        # Create the table widget
        self.table = QTableWidget()
        self.table.setStyleSheet(
            """
            QTableWidget::item { 
                background-color: #ecf0f1; 
                color: #2c3e50; 
                font-family: Arial; 
                font-size: 12px;
            }
            QTableWidget::item:selected { 
                background-color: #34495e; 
                color: white; 
            }
            QHeaderView::section { 
                background-color: #2c3e50; 
                color: white; 
                font-weight: bold; 
                padding: 4px; 
            }
            """
        )
        self.table.setSelectionMode(QTableWidget.MultiSelection)  # Allow multi-row selection
        main_layout.addWidget(self.table)

        # Set up the table columns
        self.table.setColumnCount(5)  # Five columns
        self.table.setHorizontalHeaderLabels(["Stock ID", "Stock Category", "Stock Group", "Category Group", "Manufacturer"])

        # Set column widths
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 150)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(3, 150)
        self.table.setColumnWidth(4, 150)

        # Insert the data
        self.insert_data()

        # Generate report button
        self.reportButton = QPushButton("Generate Report")
        self.reportButton.setFont(QFont("Arial", 12, QFont.Bold))
        self.reportButton.setStyleSheet(self.button_style())
        self.reportButton.clicked.connect(self.generate_report)

        # Close button
        close_button = QPushButton("Close")
        close_button.setFont(QFont("Arial", 12, QFont.Bold))
        close_button.setStyleSheet(self.button_style())
        close_button.clicked.connect(self.close)

        # Add buttons to layout
        main_layout.addWidget(self.reportButton, alignment=Qt.AlignCenter)
        main_layout.addWidget(close_button, alignment=Qt.AlignCenter)

        # Set the layout for the window
        self.setLayout(main_layout)

    def insert_data(self):
        # Data from the SQL SELECT statement
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()
        try:
            query = "SELECT * FROM tbl_ReportInventory"
            cursor.execute(query)
            data = cursor.fetchall()

            # Set the row count
            self.table.setRowCount(len(data))

            # Populate the table with the data
            for row_index, row_data in enumerate(data):
                for col_index, value in enumerate(row_data):
                    self.table.setItem(row_index, col_index, QTableWidgetItem(str(value)))
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error fetching data: {e}")
        finally:
            cursor.close()

    def generate_report(self):
        # Get selected rows
        selected_rows = self.table.selectionModel().selectedRows()

        # If no rows are selected, show a warning
        if not selected_rows:
            QMessageBox.warning(self, "Error", "No rows selected!")
            return

        # Prepare data for the selected rows
        data = []
        for index in selected_rows:
            row = index.row()
            data_row = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item:
                    data_row.append(item.text())
                else:
                    data_row.append("")
            data.append(data_row)

        # Save selected data to Excel
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["Stock ID", "Stock Category", "Stock Group", "Category Group", "Manufacturer"])
        for row in data:
            ws.append(row)

        filename, _ = QFileDialog.getSaveFileName(self, "Save Report", "", "*.xlsx")
        if filename:
            wb.save(filename)
            QMessageBox.information(self, "Success", "Report saved successfully!")
        else:
            QMessageBox.warning(self, "Error", "No file selected!")

    def button_style(self):
        """Returns the style for buttons."""
        return """
            QPushButton {
                background-color: #34495e;
                color: white;
                padding: 8px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #2c3e50;
            }
        """


if __name__ == "__main__":
    app = QApplication([])
    window = InventoryTable()
    window.show()
    app.exec_()




