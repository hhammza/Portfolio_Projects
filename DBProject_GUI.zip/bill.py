from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import Qt
from datetime import datetime

class BillGenerator(QDialog):
    def __init__(self, row_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Bill Viewer")
        self.setGeometry(200, 200, 600, 400)

        self.layout = QVBoxLayout(self)

        # Check for valid row data
        if not row_data:
            row_data = []

        # Example data (dynamic now)
        customer_name = row_data[0][4] if row_data else "Unknown Customer"
        current_date = datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.now().strftime("%H:%M:%S")

        # Prepare products from row_data
        products = []
        for row in row_data:
            try:
                product_name = row[1] if len(row) > 1 else "Unknown Product"
                quantity = float(row[2]) if len(row) > 2 else 0.0
                unit_price = float(row[3]) if len(row) > 3 else 0.0

                products.append({
                    "name": product_name,
                    "quantity": quantity,
                    "unit_price": unit_price
                })
            except (ValueError, IndexError) as e:
                print(f"Invalid data in row: {row} - Error: {e}")
                continue

        # Calculate totals
        subtotal = sum(item["quantity"] * item["unit_price"] for item in products)
        discount = 1.00
        grand_total = subtotal - discount
        payment_method = "Credit Card"
        salesman_name = "Jane Smith"

        # Header
        header_label = QLabel(f"""
        Medlink Pharmacy
        ----------------------------------------
        Customer:      {customer_name}
        Date:          {current_date}
        Time:          {current_time}
        """)
        header_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(header_label)

        # Table for products
        table = QTableWidget()
        table.setRowCount(len(products))
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["Product", "Qty", "Unit Price", "Total"])
        table.horizontalHeader().setStretchLastSection(True)

        # Corrected table data
        for row, item in enumerate(products):
            table.setItem(row, 0, QTableWidgetItem(item["name"]))  # Product
            table.setItem(row, 1, QTableWidgetItem(f"{item['quantity']}"))  # Quantity
            table.setItem(row, 2, QTableWidgetItem(f"{item['unit_price']:.2f}"))  # Unit Price
            table.setItem(row, 3, QTableWidgetItem(f"{item['quantity'] * item['unit_price']:.2f}"))  # Total

        self.layout.addWidget(table)

        # Footer
        footer_label = QLabel(f"""
        ----------------------------------------
        Subtotal:       {subtotal:.2f}
        Discount:      -{discount:.2f}
        ----------------------------------------
        Grand Total:    {grand_total:.2f}
        Payment Method: {payment_method}
        Salesperson:    {salesman_name}
        ----------------------------------------
               Thank you for your purchase!
        ----------------------------------------
        """)
        footer_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(footer_label)

        self.setLayout(self.layout)


    def send_data_to_bill(self):
        # Collect row data from the table
        row_data = []
        for row in range(self.order_table.rowCount()):
            product_item = self.order_table.item(row, 0)
            quantity_item = self.order_table.item(row, 1)
            price_item = self.order_table.item(row, 2)

            # Extract and sanitize data
            product = product_item.text() if product_item else "Unknown Product"
            quantity = (
                float(quantity_item.text()) if quantity_item and self.is_float(quantity_item.text()) else 0.0
            )
            price = (
                float(price_item.text()) if price_item and self.is_float(price_item.text()) else 0.0
            )
            customer_name = self.customer_name_input.text() or "Unknown Customer"

            # Ensure pro_code (Product Code) is defined
            pro_code = row + 1  # Assign a dummy product code (you can replace this logic)

            # Append sanitized data
            row_data.append([pro_code, product, quantity, price, customer_name])

        # Debug the row data before passing
        print("Sanitized Row Data: ", row_data)

        # Open the BillGenerator dialog
        self.bill_window = BillGenerator(row_data=row_data, parent=self)
        self.bill_window.exec_()

    # Helper method to check if a string can be converted to float
    def is_float(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False