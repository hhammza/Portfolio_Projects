import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QPushButton, QWidget, QHBoxLayout
)
from PyQt5.QtGui import QIcon

class HeaderApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Header with Buttons")
        self.setGeometry(100, 100, 1000, 600)  # Adjust the size as needed

        # Main container widget
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        # Header layout
        header_layout = QHBoxLayout()

        # Button labels and icon paths
        button_data = [
            ("customer", "path/to/customer_icon.png"),
            ("supplier", "path/to/supplier_icon.png"),
            ("sales", "path/to/sales_icon.png"),
            ("purchases", "path/to/purchases_icon.png"),
            ("stock", "path/to/stock_icon.png"),
            ("reports", "path/to/reports_icon.png"),
        ]

        # Create header buttons
        for text, icon_path in button_data:
            button = QPushButton(text)
            button.setIcon(QIcon(icon_path))  # Set the icon
            button.setStyleSheet("padding: 10px; font-size: 14px;")
            header_layout.addWidget(button)

        # Add the header layout to the main layout
        main_layout.addLayout(header_layout)

        # Empty space below header
        empty_space = QWidget()
        main_layout.addWidget(empty_space)

        # Set the main layout
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = HeaderApp()
    window.show()
    sys.exit(app.exec_())