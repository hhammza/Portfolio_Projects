import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QComboBox, QPushButton, QTextEdit, QWidget, QFrame
)
from PyQt5.QtGui import QIcon


class BookingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Booking In Page with Header")
        self.setGeometry(100, 100, 1200, 800)  # Adjusted window size

        # Main container widget
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        # Header section
        header_layout = QHBoxLayout()

        # Button labels and icon paths for header
        button_data = [
            ("customer", "path/to/customer_icon.png"),
            ("supplier", "path/to/supplier_icon.png"),
            ("sales", "path/to/sales_icon.png"),
            ("purchases", "path/to/purchases_icon.png"),
            ("stock", "path/to/stock_icon.png"),
            ("reports", "path/to/reports_icon.png"),
        ]

        # Create header buttons
        for text, icon_path in button_data:
            button = QPushButton(text)
            button.setIcon(QIcon(icon_path))  # Set the icon
            button.setStyleSheet("padding: 10px; font-size: 14px;")
            header_layout.addWidget(button)

        # Add header layout
        main_layout.addLayout(header_layout)

        # Add horizontal line for separation
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # Add vertical spacing
        main_layout.addSpacing(10)

        # Body section (Booking In Form)
        # Delivery Section
        delivery_layout = QGridLayout()
        delivery_layout.addWidget(QLabel("Entry Date:"), 0, 0)
        delivery_layout.addWidget(QLineEdit(), 0, 1)
        delivery_layout.addWidget(QLabel("PO Number:"), 0, 2)
        delivery_layout.addWidget(QLineEdit(), 0, 3)
        delivery_layout.addWidget(QLabel("Supplier Name:"), 0, 4)
        delivery_layout.addWidget(QLineEdit(), 0, 5)
        delivery_layout.addWidget(QLabel("User:"), 0, 6)
        delivery_layout.addWidget(QLineEdit(), 0, 7)

        main_layout.addLayout(delivery_layout)

        # Model Details Section
        model_layout = QGridLayout()
        model_layout.addWidget(QLabel("Category:"), 0, 0)
        model_layout.addWidget(QComboBox(), 0, 1)
        model_layout.addWidget(QLabel("Manufacturer:"), 0, 2)
        model_layout.addWidget(QComboBox(), 0, 3)
        model_layout.addWidget(QLabel("Model Name:"), 0, 4)
        model_layout.addWidget(QComboBox(), 0, 5)
        model_layout.addWidget(QLabel("Unit Cost:"), 0, 6)
        model_layout.addWidget(QLineEdit(), 0, 7)
        model_layout.addWidget(QLabel("Sell Price:"), 0, 8)
        model_layout.addWidget(QLineEdit(), 0, 9)

        model_layout.addWidget(QLabel("Sub Category:"), 1, 0)
        model_layout.addWidget(QComboBox(), 1, 1)
        model_layout.addWidget(QLabel("Stock Code:"), 1, 2)
        model_layout.addWidget(QLineEdit(), 1, 3)
        model_layout.addWidget(QLabel("P/N:"), 1, 4)
        model_layout.addWidget(QLineEdit(), 1, 5)
        model_layout.addWidget(QLabel("Fitting:"), 1, 6)
        model_layout.addWidget(QLineEdit(), 1, 7)

        model_layout.addWidget(QLabel("Description:"), 2, 0)
        description_edit = QTextEdit()
        description_edit.setPlaceholderText("Double Click to Enter Specification")
        model_layout.addWidget(description_edit, 2, 1, 1, 9)

        main_layout.addLayout(model_layout)

        # Item Details Section
        item_layout = QGridLayout()
        item_layout.addWidget(QLabel("Report:"), 0, 0)
        item_layout.addWidget(QTextEdit(), 0, 1, 1, 3)
        item_layout.addWidget(QLabel("Condition:"), 0, 4)
        item_layout.addWidget(QComboBox(), 0, 5)
        item_layout.addWidget(QLabel("Serial Number:"), 0, 6)
        item_layout.addWidget(QLineEdit(), 0, 7)
        item_layout.addWidget(QLabel("Extra Fields:"), 0, 8)
        item_layout.addWidget(QLineEdit(), 0, 9)

        item_layout.addWidget(QLabel("Grade:"), 1, 0)
        item_layout.addWidget(QLineEdit(), 1, 1)
        item_layout.addWidget(QLabel("Location:"), 1, 2)
        item_layout.addWidget(QLineEdit(), 1, 3)
        item_layout.addWidget(QLabel("Barcode Number:"), 1, 4)
        item_layout.addWidget(QLineEdit(), 1, 5, 1, 5)

        main_layout.addLayout(item_layout)

        # Buttons at the bottom
        button_layout = QHBoxLayout()
        button_layout.addWidget(QPushButton("Close"))
        button_layout.addWidget(QPushButton("Print Barcodes"))
        button_layout.addWidget(QPushButton("Finish"))

        main_layout.addLayout(button_layout)

        # Set the main layout
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BookingApp()
    window.show()
    sys.exit(app.exec_())
