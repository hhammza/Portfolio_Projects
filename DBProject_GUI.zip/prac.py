import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
import pyodbc

# Database Connection Class
class DatabaseConnection:
    _connection = None

    @staticmethod
    def get_connection():
        if DatabaseConnection._connection is None:
            try:
                # Define connection parameters
                server = r'DESKTOP-7LVJP7N\SQLEXPRESS'  # Use raw string to avoid escape issues
                database = 'db_PharmacyProject'  # Replace with your database name

                # Create the connection string
                connection_string = (
                    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
                    f'SERVER={server};DATABASE={database};Trusted_Connection=yes'
                )

                # Establish the connection
                DatabaseConnection._connection = pyodbc.connect(connection_string)
                print("Database connection established!")
            except pyodbc.Error as e:
                print("Error connecting to SQL Server:", e)
                raise
        return DatabaseConnection._connection

# User Input Page
class UserInputPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("User Information Form")
        self.setGeometry(100, 100, 300, 200)  # Set window size

        # Main layout
        main_layout = QVBoxLayout()

        # Username
        main_layout.addWidget(QLabel("Username:"))
        self.username_entry = QLineEdit()
        main_layout.addWidget(self.username_entry)

        # City
        main_layout.addWidget(QLabel("City:"))
        self.city_entry = QLineEdit()
        main_layout.addWidget(self.city_entry)

        # Submit Button
        submit_button = QPushButton("Submit")
        submit_button.clicked.connect(self.submit_details)
        main_layout.addWidget(submit_button)

        self.setLayout(main_layout)

    def submit_details(self):
        # Get the input from the text fields
        username = self.username_entry.text()
        city = self.city_entry.text()

        # Check if the fields are not empty
        if not username or not city:
            QMessageBox.warning(self, "Input Error", "Please fill in all fields!")
            return

        # Save to database
        try:
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Insert data into the `users` table
            insert_query = """
                INSERT INTO users (user_names, city) VALUES (?, ?)
            """
            cursor.execute(insert_query, (username, city))
            connection.commit()

            QMessageBox.information(self, "Success", "Data saved successfully!")

            # Clear the input fields after submission
            self.username_entry.clear()
            self.city_entry.clear()
        except pyodbc.Error as e:
            QMessageBox.critical(self, "Database Error", f"Failed to save data: {e}")
            print("Database Error:", e)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UserInputPage()
    window.show()
    sys.exit(app.exec_())