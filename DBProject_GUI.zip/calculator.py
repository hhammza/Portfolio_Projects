import sys
from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QWidget, QApplication
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class Calculator(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Calculator")
        self.setGeometry(100, 100, 300, 400)
        self.setStyleSheet("background-color: #ecf0f1;")  # Light gray background

        # Layout
        main_layout = QVBoxLayout()

        # Display
        self.display = QLineEdit()
        self.display.setFont(QFont("Arial", 16))
        self.display.setAlignment(Qt.AlignRight)
        self.display.setStyleSheet("""
            background-color: #ffffff;
            color: #2c3e50;
            border: 2px solid #bdc3c7;
            border-radius: 8px;
            padding: 5px;
        """)
        main_layout.addWidget(self.display)

        # Buttons Layout
        buttons_layout = QVBoxLayout()
        self.create_buttons(buttons_layout)
        main_layout.addLayout(buttons_layout)

        self.setLayout(main_layout)

    def create_buttons(self, layout):
        button_values = [
            ["7", "8", "9", "/"],
            ["4", "5", "6", "*"],
            ["1", "2", "3", "-"],
            ["C", "0", "=", "+"]
        ]

        button_style = """
            QPushButton {
                background-color: #3498db;
                color: white;
                font-size: 14px;
                border: none;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """

        for row in button_values:
            row_layout = QHBoxLayout()
            for value in row:
                button = QPushButton(value)
                button.setFont(QFont("Arial", 14))
                button.setFixedSize(60, 60)
                button.setStyleSheet(button_style)
                button.clicked.connect(self.handle_button_click)
                row_layout.addWidget(button)
            layout.addLayout(row_layout)

    def handle_button_click(self):
        sender = self.sender()
        text = sender.text()

        if text == "C":
            self.display.clear()
        elif text == "=":
            try:
                result = eval(self.display.text())
                self.display.setText(str(result))
            except Exception:
                self.display.setText("Error")
        else:
            self.display.setText(self.display.text() + text)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Calculator()
    window.show()
    sys.exit(app.exec_())