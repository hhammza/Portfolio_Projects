from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, pyqtSignal
import pyodbc
from DBconnectivity import DatabaseConnection

class DeleteProduct(QWidget):
    product_delete = pyqtSignal()
    def __init__(self):
        super().__init__()

        # Set window properties
        self.setWindowTitle("Delete Product")
        self.setGeometry(300, 200, 400, 200)

        # Main layout container
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Product")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        id_label = QLabel("Product ID or Name:")
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("Enter Product ID or Name")
        input_layout.addWidget(id_label)
        input_layout.addWidget(self.id_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        self.delete_button = QPushButton("Delete Product")
        self.delete_button.setStyleSheet("background-color: darkblue; color: white; padding: 5px 15px;")
        self.delete_button.clicked.connect(self.delete_product)  # Corrected this line
        main_layout.addWidget(self.delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_product(self):
        product_input_to_delete = self.id_input.text().strip()

        if not product_input_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Product ID or Name.")
            return

        try:
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Try to detect if the input is a number (Product ID) or a string (Product Name)
            if product_input_to_delete.isdigit():  # If the input is numeric, it's likely a product ID
                query = "SELECT product_id, product_name FROM tbl_Products WHERE product_id = ?"
                cursor.execute(query, (int(product_input_to_delete),))  # Cast to int
                self.product_delete.emit()
            else:  # Otherwise, it's a product name
                query = "SELECT product_id, product_name FROM tbl_Products WHERE product_name = ?"
                cursor.execute(query, (product_input_to_delete,))

            product = cursor.fetchone()

            if product:
                product_id = product[0]
                product_name = product[1]

                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the product: {product_name} (ID: {product_id})?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    # Step 1: Delete from tbl_product_history first
                    delete_history_query = "DELETE FROM tbl_product_history WHERE product_ID = ?"
                    cursor.execute(delete_history_query, (product_id,))

                    # Step 2: Execute the DELETE query on tbl_Products
                    delete_product_query = "DELETE FROM tbl_Products WHERE product_id = ?"
                    cursor.execute(delete_product_query, (product_id,))
                    connection.commit()

                    QMessageBox.information(self, "Success", f"Product '{product_name}' deleted successfully.")
                    self.clear_fields()
            else:
                QMessageBox.warning(self, "Not Found", "No product found with the specified ID or Name.")

        except pyodbc.Error as e:
            QMessageBox.critical(self, "Database Error", f"Error deleting product: {e}")
        finally:
            cursor.close()

    def clear_fields(self):
        """Clears the input field after deletion."""
        self.id_input.clear()


# To test the DeleteProduct widget independently
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = DeleteProduct()
    window.show()
    sys.exit(app.exec_())
