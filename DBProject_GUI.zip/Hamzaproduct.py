import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from AddProduct import AddProduct
from DeleteProduct import DeleteProduct
from UpdateProduct import UpdateProduct
from DBconnectivity import DatabaseConnection
from orders import PharmacyPage

class ProductPage(QMainWindow):
    def __init__(self, pharmacy_page):
        super().__init__()
        self.orders_page = pharmacy_page

        # Set up the main window
        self.setWindowTitle("Medlink_Products")
        self.setGeometry(600, 200, 800, 600)
        self.setFixedHeight(700)
        self.setFixedWidth(955)

        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Medicine:")
        self.search_input = QLineEdit()
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(100)
        self.medicine_table.setColumnCount(7)
        self.medicine_table.setHorizontalHeaderLabels([
            "Product Name", "Unit_Price", "Cost_Price", "Manufacture_Date", "Expiry_Date", "Quantity", "Category"
        ])
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        add_button = QPushButton("Add Product")
        update_button = QPushButton("Update Product")
        delete_button = QPushButton("Delete Product")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(add_button)
        buttons_layout.addWidget(update_button)
        buttons_layout.addWidget(delete_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by FHH | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Central widget setup
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        add_button.clicked.connect(self.show_add_product)
        update_button.clicked.connect(self.show_update_product)
        delete_button.clicked.connect(self.show_delete_product)
        exit_button.clicked.connect(self.close)

        self.display_products()
        self.medicine_table.cellClicked.connect(self.row_clicked)

    # def row_clicked(self, row, column):
    #     try:
    #         # Extract data from the clicked row
    #         row_data = self.get_row_data(row)
    #
    #         if not self.orders_page:
    #             print("Orders page (PharmacyPage) is not initialized.")
    #             return
    #
    #         # Add the row data to the orders page
    #         self.orders_page.add_row_to_table(row_data)
    #     except Exception as e:
    #         print(f"Error in row_clicked: {e}")
    #
    # def get_row_data(self, row):
    #     row_data = []
    #     for col in [0, 1, 3, 4, 6]:  # Columns to extract data from
    #         item = self.medicine_table.item(row, col)
    #         row_data.append(item.text() if item else "")
    #     return row_data

    self.row_data = []
    def get_row(self, row, column):
        try:
            # Clear previous row data
            self.row_data.clear()
            # Extract data from the clicked row
            for col in [0, 1, 3, 4, 6]:  # Columns to extract data from
                item = self.medicine_table.item(row, col)
                self.row_data.append(item.text() if item else "")
        except Exception as e:
            print(f"Error in get_row: {e}")

    def pass_row(self):
        return self.row_data

    # def row_clicked(self, row, column):
    #     try:
    #         # Extract data from the clicked row
    #         row_data = []
    #         for col in [0, 1, 3, 4, 6]:  # Columns to extract data from
    #             item = self.medicine_table.item(row, col)
    #             row_data.append(item.text() if item else "")
    #
    #         if not self.orders_page:
    #             print("Orders page (PharmacyPage) is not initialized.")
    #             return
    #
    #         # Add the row data to the orders page
    #         self.orders_page.add_row_to_table(row_data)
    #     except Exception as e:
    #         print(f"Error in row_clicked: {e}")

    def search_medicine(self):
        search_input = self.search_input.text()
        try:
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            cursor.execute("EXEC SearchProductByName @ProductName = ?", (search_input,))
            results = cursor.fetchall()

            self.medicine_table.setRowCount(0)  # Clear the table

            for row_index, product in enumerate(results):
                self.medicine_table.insertRow(row_index)
                for col_index, value in enumerate(product):
                    self.medicine_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

            if not results:
                QMessageBox.information(self, "No Results", "No products found matching the search query.")
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to fetch data: {e}")
            print("Database Error:", e)

    def display_products(self):
        try:
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            display_query = "SELECT * FROM view_product ORDER BY product_name"
            cursor.execute(display_query)
            products = cursor.fetchall()

            self.medicine_table.setRowCount(len(products))

            for row_index, product in enumerate(products):
                for col_index, value in enumerate(product):
                    self.medicine_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to fetch data: {e}")
            print("Database Error:", e)

    def show_add_product(self):
        self.product_page = AddProductsPage()
        self.product_page.show()

    def show_update_product(self):
        self.product = UpdateProduct()
        self.product.show()

    def show_delete_product(self):
        self.product = DeleteProduct()
        self.product.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)

    # class MockPharmacyPage:
    #     def add_row_to_table(self, row_data):
    #         row_data.append("1")  # Appending extra data as required
    #         row_data.append("1")
    #         print(f"Row data to add: {row_data}")
    #         try:
    #             if not hasattr(self, 'medicine_table') or self.medicine_table is None:
    #                 print("Medicine table is not initialized.")
    #                 return
    # 
    #             # Insert a new row in the table
    #             row_count = self.medicine_table.rowCount()
    #             self.medicine_table.insertRow(row_count)
    # 
    #             # Insert data into the new row
    #             for col_index, value in enumerate(row_data):
    #                 self.medicine_table.setItem(row_count, col_index, QTableWidgetItem(str(value)))
    # 
    #             print(f"Row successfully added: {row_data}")
    #         except Exception as e:
    #             print(f"Error in add_row_to_table: {e}")

    pharmacy_page = PharmacyPage
    window = ProductPage(pharmacy_page)
    window.show()
    sys.exit(app.exec_())