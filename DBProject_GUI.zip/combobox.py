import sys
from PyQt5.QtWidgets import QApplication, QLabel, QComboBox, QVBoxLayout, QWidget

def create_window():
    # Create the main application window
    app = QApplication(sys.argv)
    window = QWidget()
    window.setWindowTitle("Medicine Category Selector")

    # Create a layout
    main_layout = QVBoxLayout()

    # Add a label
    main_layout.addWidget(QLabel("Category of Medicine:"))

    # Create and configure the combo box
    combo_box = QComboBox()
    categories = ["Analgesics", "Antibiotics", "Antiseptics", "Vaccines", "Antipyretics"]
    combo_box.addItems(categories)

    # Add the combo box to the layout
    main_layout.addWidget(combo_box)

    # Set the layout for the window
    window.setLayout(main_layout)

    # Display the window
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    create_window()
