import pyodbc
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from DBconnectivity import DatabaseConnection

class UpdateProduct(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Update Product")
        self.setGeometry(800, 300, 400, 400)

        # Set background color to light blue
        self.setStyleSheet("background-color: lightblue;")

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for product details
        self.create_field(main_layout, "Product ID:", "product_input")
        self.create_field(main_layout, "Product Name:", "name_input")
        self.create_field(main_layout, "Unit Price:", "unit_price_input")
        self.create_field(main_layout, "Cost Price:", "cost_price_input")
        self.create_field(main_layout, "In Stock:", "stock_input")
        self.create_field(main_layout, "Batch Number:", "batch_number_input")
        self.create_field(main_layout, "Category:", "category_input")
        self.create_field(main_layout, "Manufacture Date:", "manufacture_date_input")
        self.create_field(main_layout, "Expiry Date:", "exp_date_input")

        # Update Product button
        update_product_button = QPushButton("Update Product")
        update_product_button.setFont(QFont("Arial", 12))
        update_product_button.setStyleSheet(
            "background-color: blue; color: white; padding: 5px; border-radius: 5px;"
        )
        update_product_button.clicked.connect(self.update_product)
        main_layout.addWidget(update_product_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12))
        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)  # Set a fixed width for uniformity

        # Set white background for the input fields
        input_field.setStyleSheet("background-color: white; color: black; padding: 2px;")

        setattr(self, input_name, input_field)  # Dynamically create an attribute for each input field
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def update_product(self):
        """
        Logic to update product details in the database.
        """
        p_id = self.product_input.text()
        name = self.name_input.text()
        unit_price = self.unit_price_input.text()
        cost_price = self.cost_price_input.text()
        stock = self.stock_input.text()
        batch_number = self.batch_number_input.text()
        category = self.category_input.text()
        manufacture_date = self.manufacture_date_input.text()
        exp_date = self.exp_date_input.text()

        # Perform validation or save logic here
        if not p_id or not name or not unit_price or not cost_price or not stock or not batch_number or not category or not manufacture_date or not exp_date:
            QMessageBox.warning(self, "Input Error", "Please fill all the fields!")
            return

        try:
            # Ensure that numerical fields are valid
            unit_price = float(unit_price)
            cost_price = float(cost_price)
            stock = int(stock)
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Unit Price, Cost Price, and Stock must be valid numbers!")
            return

        # Calculate stock price
        stock_price = unit_price * stock

        try:
            # Connect to the database and update the product details
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Update product query
            query = """
                UPDATE tbl_Products
                SET product_name = ?, unit_price = ?, cost_price = ?, Instock = ?, batch_number = ?, category = ?, manufacture_date = ?, exp_date = ?, stock_price = ?
                WHERE product_id = ?
            """
            cursor.execute(query, (name, unit_price, cost_price, stock, batch_number, category, manufacture_date, exp_date, stock_price, p_id))
            connection.commit()

            QMessageBox.information(self, "Success", f"Product '{name}' updated successfully.")

            # Clear the fields after updating the product
            self.clear_fields()

        except pyodbc.Error as e:
            QMessageBox.warning(self, "Database Error", f"Error updating product in the database: {e}")
        finally:
            cursor.close()

    def clear_fields(self):
        """Clears all input fields after updating a product."""
        self.product_input.clear()
        self.name_input.clear()
        self.unit_price_input.clear()
        self.cost_price_input.clear()
        self.stock_input.clear()
        self.batch_number_input.clear()
        self.category_input.clear()
        self.manufacture_date_input.clear()
        self.exp_date_input.clear()

# To test the UpdateProduct widget independently
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = UpdateProduct()
    window.show()
    sys.exit(app.exec_())
