import sys

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox, QApplication
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

from DBconnectivity import DatabaseConnection

'''
class DeleteManufacturer(QWidget):
    def __init__(self, customer_table):
        super().__init__()
        self.customer_table = customer_table

        # Set window properties
        self.setWindowTitle("Delete Manufacturer")
        self.setGeometry(300, 200, 400, 200)

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Manufacturer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        self.supp_label = QLabel("Manufacturer ID:")
        self.supp_input = QLineEdit()
        self.supp_input.setPlaceholderText("Enter ID")
        input_layout.addWidget(self.supp_label)
        input_layout.addWidget(self.supp_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        self.delete_button = QPushButton("Delete Manufacturer")
        self.delete_button.setStyleSheet("background-color: blue; color: white; padding: 5px 15px;")
        self.delete_button.clicked.connect(self.delete_manufacturer)
        main_layout.addWidget(self.delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_manufacturer(self):
        manu_to_delete = self.supp_input.text().strip()

        if not manu_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid ID.")
            return
        # Search for the customer in the table
        for row in range(self.customer_table.rowCount()):
            manu_item = self.customer_table.item(row, 0)  # Assuming CNIC is in column 0
            if manu_item and manu_item.text() == manu_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the Supplier with ID: {manu_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.customer_table.removeRow(row)
                    QMessageBox.information(self, "Success", "Customer deleted successfully.")
                return

        QMessageBox.warning(self, "Not Found", "Supplier with the specified ID does not exist.")

if __name__ == "__main__":
    from PharmacySystem.GUI_DB.customer import CustomerPage
    app = QApplication(sys.argv)
    window = DeleteManufacturer()
    window.show()
    sys.exit(app.exec_())'''

'''
class DeleteManufacturer(QWidget):
    def __init__(self, supp_table):
        super().__init__()
        self.supp_table = supp_table

        # Set window properties
        self.setWindowTitle("Delete Manufacturer")
        self.setGeometry(300, 200, 400, 200)

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Manufacturer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        id_label = QLabel("Manufacturer ID:")
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("Enter Manufacturer ID")
        input_layout.addWidget(id_label)
        input_layout.addWidget(self.id_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        self.delete_button = QPushButton("Delete Manufacturer")
        self.delete_button.setStyleSheet("background-color: blue; color: white; padding: 5px 15px;")
        self.delete_button.clicked.connect(self.delete_manufacturer)
        main_layout.addWidget(self.delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_manufacturer(self):
        manufacturer_id_to_delete = self.id_input.text().strip()

        if not manufacturer_id_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Customer ID.")
            return

        # Search for the customer in the table
        for row in range(self.supp_table.rowCount()):
            id_item = self.supp_table.item(row, 0)  # Assuming Customer ID is in column 0
            if id_item and id_item.text() == manufacturer_id_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the supplier with ID: {manufacturer_id_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.supp_table.removeRow(row)

                    # Database deletion logic
                    connection = DatabaseConnection.get_connection()
                    cursor = connection.cursor()
                    try:
                        query = "DELETE FROM tbl_Manufacturer WHERE manufacturer_ID = ?"
                        cursor.execute(query, (manufacturer_id_to_delete,))
                        connection.commit()
                        QMessageBox.information(self, "Success", "Manufacturer deleted successfully.")
                    except Exception as e:
                        QMessageBox.critical(self, "Database Error", f"Error deleting Manufacturer: {e}")
                    finally:
                        cursor.close()
                return

        QMessageBox.warning(self, "Not Found", "Manufacturer with the specified ID does not exist.")'''

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QMessageBox, QHBoxLayout, QLineEdit, QLabel, QPushButton, QVBoxLayout, QWidget

from DBconnectivity import DatabaseConnection


class DeleteManufacturer(QWidget):
    def __init__(self, supp_table):
        super().__init__()
        self.supp_table = supp_table

        # Set window properties
        self.setWindowTitle("Delete Manufacturer")
        self.setGeometry(800, 300, 400, 200)

        # Set background color to match DeleteSupplier
        self.setStyleSheet("background-color: #f5f6fa;")  # Light Gray Background

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Manufacturer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        header_label.setStyleSheet("color: #2c3e50;")  # Dark Text Color
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        id_label = QLabel("Manufacturer ID:")
        id_label.setFont(QFont("Arial", 12, QFont.Bold))
        id_label.setStyleSheet("color: #2c3e50;")

        self.id_input = QLineEdit()
        self.id_input.setFont(QFont("Arial", 12))
        self.id_input.setFixedWidth(250)
        self.id_input.setStyleSheet("""
            QLineEdit {
                background-color: #ecf0f1; 
                color: #2c3e50; 
                padding: 5px; 
                border: 1px solid #bdc3c7; 
                border-radius: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #3498db;
            }
        """)
        self.id_input.setPlaceholderText("Enter Manufacturer ID")
        input_layout.addWidget(id_label)
        input_layout.addWidget(self.id_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        delete_button = QPushButton("Delete Manufacturer")
        delete_button.setFont(QFont("Arial", 12, QFont.Bold))
        delete_button.setStyleSheet("""
            QPushButton {
                background-color: #005A8D; 
                color: white; 
                padding: 8px; 
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
        """)
        delete_button.clicked.connect(self.delete_manufacturer)
        main_layout.addWidget(delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_manufacturer(self):
        manufacturer_id_to_delete = self.id_input.text().strip()

        if not manufacturer_id_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Manufacturer ID.")
            return

        # Search for the manufacturer in the table
        for row in range(self.supp_table.rowCount()):
            id_item = self.supp_table.item(row, 0)  # Assuming Manufacturer ID is in column 0
            if id_item and id_item.text() == manufacturer_id_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the manufacturer with ID: {manufacturer_id_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.supp_table.removeRow(row)

                    # Database deletion logic
                    connection = DatabaseConnection.get_connection()
                    cursor = connection.cursor()
                    try:
                        query = "DELETE FROM tbl_Manufacturer WHERE manufacturer_ID = ?"
                        cursor.execute(query, (manufacturer_id_to_delete,))
                        connection.commit()
                        QMessageBox.information(self, "Success", "Manufacturer deleted successfully.")
                    except Exception as e:
                        QMessageBox.critical(self, "Database Error", f"Error deleting manufacturer: {e}")
                    finally:
                        cursor.close()
                return

        QMessageBox.warning(self, "Not Found", "Manufacturer with the specified ID does not exist.")

