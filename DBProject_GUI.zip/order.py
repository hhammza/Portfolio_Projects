from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit, QTableWidget, QFrame
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from connection1 import DatabaseConnection

class PharmacyPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback

        # Main layout container
        main_layout = QVBoxLayout()

        # Add a horizontal line after the header
        horizontal_line = QFrame()
        horizontal_line.setFrameShape(QFrame.HLine)
        horizontal_line.setFrameShadow(QFrame.Sunken)
        horizontal_line.setStyleSheet("color: lightgray;")
        main_layout.addWidget(horizontal_line)

        # Input Fields Section
        fields_layout_1 = QHBoxLayout()
        customer_name_label = QLabel("Customer Name:")
        customer_name_input = QLineEdit()
        address_label = QLabel("Address:")
        address_input = QLineEdit()
        fields_layout_1.addWidget(customer_name_label)
        fields_layout_1.addWidget(customer_name_input)
        fields_layout_1.addWidget(address_label)
        fields_layout_1.addWidget(address_input)
        main_layout.addLayout(fields_layout_1)

        fields_layout_2 = QHBoxLayout()
        contact_label = QLabel("Contact:")
        contact_input = QLineEdit()
        adjustment_label = QLabel("Adjustment:")
        adjustment_input = QLineEdit()
        fields_layout_2.addWidget(contact_label)
        fields_layout_2.addWidget(contact_input)
        fields_layout_2.addWidget(adjustment_label)
        fields_layout_2.addWidget(adjustment_input)
        main_layout.addLayout(fields_layout_2)

        fields_layout_3 = QHBoxLayout()
        net_total_label = QLabel("Net Total:")
        net_total_input = QLineEdit()
        print_receipt_button = QPushButton("Print Receipt")
        fields_layout_3.addWidget(net_total_label)
        fields_layout_3.addWidget(net_total_input)

        main_layout.addLayout(fields_layout_3)

        fields_layout_4 = QHBoxLayout()
        fields_layout_4.addWidget(print_receipt_button)
        main_layout.addLayout(fields_layout_4)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(5)
        self.medicine_table.setColumnCount(6)
        self.medicine_table.setHorizontalHeaderLabels(
            ["Product Code", "Product Name", "Price", "Cost Price", "Stock", "Batch number"]
        )
        main_layout.addWidget(self.medicine_table)
    
        self.setLayout(main_layout)