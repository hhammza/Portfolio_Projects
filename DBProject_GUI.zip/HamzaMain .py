import sys
from PyQt5.QtWidgets import (QApplication, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QLabel, QLineEdit, QTextEdit,
                             QStackedWidget)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

from orders import PharmacyPage
from customer import CustomerPage
from manufacturer import ManuPage
from returnP import ReturnPage
from supplier import SupplierPage
from product import ProductPage
from InventoryReport import InventoryTable
'''
# Main Window Class
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Set full window size and light blue background
        self.setWindowState(Qt.WindowMaximized)

        # Main layout
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 40, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(header_label)

        # Create content widgets
        self.customer = CustomerPage(self.show_order)
        self.order = PharmacyPage(self.show_customer)
        self.manu = ManuPage(self.show_manufac)
        self.returns = ReturnPage(self.show_returns)
        self.supp = SupplierPage(self.show_suppliers)

        # Buttons to switch content
        self.button_order = QPushButton("Home")
        self.button_customer = QPushButton("Customer")
        self.button_return = QPushButton("Returns")
        self.button_supp = QPushButton("Supplier")
        self.button_manuf = QPushButton("Manufacturer")
        self.product = QPushButton("Products")

        # Set button styles
        for button in [
            self.button_order,
            self.button_customer,
            self.button_return,
            self.button_supp,
            self.button_manuf,
            self.product,
        ]:
            button.setStyleSheet("background-color: #0078D7; color: white;"
                                 "padding: 20px;")

        # Connect buttons to methods
        self.button_order.clicked.connect(self.show_order)
        self.button_customer.clicked.connect(self.show_customer)
        self.button_return.clicked.connect(self.show_returns)
        self.button_supp.clicked.connect(self.show_suppliers)
        self.button_manuf.clicked.connect(self.show_manufac)
        self.product.clicked.connect(self.open_product_page)

        # Create a horizontal layout for buttons
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.button_order)
        button_layout.addWidget(self.button_customer)
        button_layout.addWidget(self.button_return)
        button_layout.addWidget(self.button_supp)
        button_layout.addWidget(self.button_manuf)
        button_layout.addWidget(self.product)

        # Add the horizontal button layout to the main layout
        self.layout.addLayout(button_layout)


    def switch_content(self, widget_to_show):
        # Hide all widgets first
        for widget in [self.order, self.customer, self.manu, self.supp, self.returns]:
            if widget.isVisible():
                self.layout.removeWidget(widget)
                widget.setParent(None)

        # Add the widget to show
        self.layout.addWidget(widget_to_show)

    def show_customer(self):
        self.switch_content(self.customer)

    def show_order(self):
        self.switch_content(self.order)

    def show_manufac(self):
        self.switch_content(self.manu)

    def show_suppliers(self):
        self.switch_content(self.supp)

    def show_returns(self):
        self.switch_content(self.returns)

    def show_receipt(self):
        print("Receipt button clicked")

    def show_inventory(self):
        self.inventory_page = InventoryTable()
        self.inventory_page.show()

    def open_product_page(self):
        """Open the ProductPage in a new window."""
        self.product_page = ProductPage(self)
        self.product_page.show()

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())'''

'''

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Set full window size and light blue background
        self.setWindowState(Qt.WindowMaximized)
        self.setStyleSheet("background-color: #f1f8f8;")  # Light gray-blue background

        # Main layout with a vertical stack
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Header Section with modern font and gradient background
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 40, QFont.Bold))
        header_label.setStyleSheet("""
            color: #2c3e50;
            background-color: #16a085;
            padding: 20px;
            border-radius: 10px;
        """)
        header_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(header_label)

        # Create stacked widget to switch between different pages
        self.stacked_widget = QStackedWidget()
        
        self.layout.addWidget(self.stacked_widget)

        # Create pages for each section
        self.customer = CustomerPage(self.show_order)
        self.order = PharmacyPage(self.show_customer)
        self.manu = ManuPage(self.show_manufac)
        self.returns = ReturnPage(self.show_returns)
        self.supp = SupplierPage(self.show_suppliers)

        # Add the pages to the stacked widget
        self.stacked_widget.addWidget(self.order)
        self.stacked_widget.addWidget(self.customer)
        self.stacked_widget.addWidget(self.manu)
        self.stacked_widget.addWidget(self.returns)
        self.stacked_widget.addWidget(self.supp)

        # Buttons to switch content
        self.button_order = QPushButton("Home")
        self.button_customer = QPushButton("Customer")
        self.button_return = QPushButton("Returns")
        self.button_supp = QPushButton("Supplier")
        self.button_manuf = QPushButton("Manufacturer")
        self.product = QPushButton("Products")
        # Create a horizontal layout for buttons
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.button_order)
        button_layout.addWidget(self.button_customer)
        button_layout.addWidget(self.button_return)
        button_layout.addWidget(self.button_supp)
        button_layout.addWidget(self.button_manuf)
        button_layout.addWidget(self.product)

        # Add the horizontal button layout to the main layout
        self.layout.addLayout(button_layout)

        # Modern button styles with shadow effects and gradients
        for button in [
            self.button_order,
            self.button_customer,
            self.button_return,
            self.button_supp,
            self.button_manuf,
            self.product,
        ]:
            button.setStyleSheet("""
                QPushButton {
                    background-color: #1abc9c;
                    color: white;
                    border-radius: 15px;
                    padding: 12px;
                    margin: 5px;
                    font-size: 16px;
                    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
                }
                QPushButton:hover {
                    background-color: #16a085;
                    box-shadow: 0px 6px 8px rgba(0, 0, 0, 0.3);
                }
            """)

        # Connect buttons to methods
        self.button_order.clicked.connect(self.show_order)
        self.button_customer.clicked.connect(self.show_customer)
        self.button_return.clicked.connect(self.show_returns)
        self.button_supp.clicked.connect(self.show_suppliers)
        self.button_manuf.clicked.connect(self.show_manufac)
        self.product.clicked.connect(self.open_product_page)



    def show_content(self, index):
        self.stacked_widget.setCurrentIndex(index)

    def show_customer(self):
        self.show_content(1)

    def show_order(self):
        self.show_content(0)

    def show_manufac(self):
        self.show_content(2)

    def show_suppliers(self):
        self.show_content(3)

    def show_returns(self):
        self.show_content(4)

    def open_product_page(self):
        """Open the ProductPage in a new window."""
        self.product_page = ProductPage(self)
        self.product_page.show()

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())'''
import sys
from PyQt5.QtWidgets import (
    QApplication, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QLabel, QStackedWidget, QFrame
)
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt, QSize

from orders import PharmacyPage
from customer import CustomerPage
from manufacturer import ManuPage
from returnP import ReturnPage
from supplier import SupplierPage
from product import ProductPage


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Window settings
        self.setWindowState(Qt.WindowMaximized)
        self.setWindowTitle("Medlink Pharmacy")
        self.setStyleSheet("background-color: #ecf0f1;")  # Soft gray background

        # Main layout
        main_layout = QHBoxLayout(self)
        self.setLayout(main_layout)

        # Sidebar navigation (Left Panel)
        sidebar = QFrame()
        sidebar.setStyleSheet("background-color: #2c3e50; border-right: 2px solid #34495e;")
        sidebar.setFixedWidth(300)  # Width adjusted for longer text
        sidebar_layout = QVBoxLayout()
        sidebar.setLayout(sidebar_layout)

        # Header Section
        title_label = QLabel("Medlink Pharmacy")
        title_label.setFont(QFont("Arial", 20, QFont.Bold))
        title_label.setStyleSheet("color: white; padding: 15px;")
        title_label.setAlignment(Qt.AlignCenter)
        sidebar_layout.addWidget(title_label)

        # Sidebar Buttons with Icons
        self.buttons = {
            "Home": QPushButton("  Order"),
            "Customer": QPushButton("  Customer"),
            "Returns": QPushButton("  Returns"),
            "Supplier": QPushButton("  Supplier"),
            "Manufacturer": QPushButton("  Manufacturer"),
            "Products": QPushButton("  Products"),
        }

        icons = [
            "dashboard.png", "customer.png", "return.png",
            "trucksupplier.png", "manufacture.png", "products.png"
        ]

        for idx, (name, button) in enumerate(self.buttons.items()):
            button.setFont(QFont("Arial", 12))
            button.setStyleSheet(self.button_style())
            button.setIcon(QIcon(icons[idx]))  # Add icons (ensure icons are available)
            button.setIconSize(QSize(20, 20))
            button.setFixedHeight(50)
            button.clicked.connect(lambda checked, n=name: self.navigate(n))
            sidebar_layout.addWidget(button)

        sidebar_layout.addStretch()
        main_layout.addWidget(sidebar)

        # Content Area (Right Panel)
        self.stacked_widget = QStackedWidget()
        self.pages = {
            "Home": PharmacyPage(self.show_order),
            "Customer": CustomerPage(self.show_customer),
            "Returns": ReturnPage(self.show_returns),
            "Supplier": SupplierPage(self.show_suppliers),
            "Manufacturer": ManuPage(self.show_manufac),
            "Products": ProductPage()
        }
        for page in self.pages.values():
            self.stacked_widget.addWidget(page)

        main_layout.addWidget(self.stacked_widget)

        # Set default page
        self.navigate("Home")

    def navigate(self, name):
        """Switch to the selected page"""
        page = self.pages.get(name)
        if page:
            self.stacked_widget.setCurrentWidget(page)

        # Highlight active button
        for button_name, button in self.buttons.items():
            if button_name == name:
                button.setStyleSheet(self.button_style(active=True))
            else:
                button.setStyleSheet(self.button_style())

    def button_style(self, active=False):
        """Dynamic button style for active and inactive states"""
        if active:
            return """
                QPushButton {
                    background-color: #16a085;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #1abc9c;
                }
            """
        else:
            return """
                QPushButton {
                    background-color: #34495e;
                    color: white;
                    border: none;
                    border-radius: 10px;
                    padding: 10px;
                }
                QPushButton:hover {
                    background-color: #2c3e50;
                }
            """
    def show_content(self, index):
        self.stacked_widget.setCurrentIndex(index)

    def show_customer(self):
        self.show_content(1)

    def show_order(self):
        self.show_content(0)

    def show_manufac(self):
        self.show_content(2)

    def show_suppliers(self):
        self.show_content(3)

    def show_returns(self):
        self.show_content(4)

    def open_product_page(self):
        self.product_page = ProductPage(self)
        self.product_page.show()

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())