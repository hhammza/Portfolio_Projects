import pyodbc
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, pyqtSignal

from DBconnectivity import DatabaseConnection

'''
class AddManufacturer(QWidget):
    manufacturer_added = pyqtSignal()
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Add Manufacturer")
        self.setGeometry(800, 300, 400, 300)

        # Set background color to light blue
        self.setStyleSheet("background-color: lightblue;")

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for customer details
        self.create_field(main_layout, "Manufacturer Name", "name_input")
        self.create_field(main_layout, "Phone:", "phone_input")
        self.create_field(main_layout, "Email:", "email_input")
        self.create_field(main_layout, "Supplier Address:", "address_input")

        # Add Customer button
        add_manufacturer_button = QPushButton("Add Manufacturer")
        add_manufacturer_button.setFont(QFont("Arial", 12))
        add_manufacturer_button.setStyleSheet(
            "background-color: blue; color: white; padding: 5px; border-radius: 5px;"
        )
        add_manufacturer_button.clicked.connect(self.add_manufacturer)
        main_layout.addWidget(add_manufacturer_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12))
        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)
        setattr(self, input_name, input_field)  # Dynamically create an attribute for each input field++++++++
        input_field.setStyleSheet("background-color: white; color: black; padding: 2px;")
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def add_manufacturer(self):
        """
        Logic to handle adding a customer when the button is clicked.
        """
        name = self.name_input.text()
        phone = self.phone_input.text()
        email = self.email_input.text()
        address = self.address_input.text()

        # Perform validation or save logic here
        if not name or not address or not phone or not email:
            print("Please fill all the fields!")
        else:
            try:
                connection = DatabaseConnection.get_connection()
                cursor = connection.cursor()

                query = "INSERT INTO tbl_Manufacturer (manufacturer_name, manufacturer_phone, manufacturer_email, manufacturer_address)
                               VALUES (?, ?, ?, ?)"

                cursor.execute(query, (name, phone, email, address))
                connection.commit()
                print(f"Manufacturer added: Name={name}, Phone={phone}, Email={email}, Address={address}")
                # Clear the fields after adding the customer
                self.clear_fields()
                self.manufacturer_added.emit()
            except pyodbc.Error as e:
                print(f"Error adding manufacturer to the database: {e}")
            finally:
                cursor.close()

    def clear_fields(self):
        """
        Clears all input fields after adding a customer.
        """
        self.name_input.clear()
        self.phone_input.clear()
        self.email_input.clear()
        self.address_input.clear()


# To test the AddCustomer widget independently
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = AddManufacturer()
    window.show()
    sys.exit(app.exec_())'''
class AddManufacturer(QWidget):
    manufacturer_added = pyqtSignal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Add Manufacturer")
        self.setGeometry(800, 300, 400, 300)

        # Set background color to a darker contrast
        self.setStyleSheet("background-color: #f5f6fa;")  # Light Gray Background

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for manufacturer details
        self.create_field(main_layout, "Manufacturer Name:", "name_input")
        self.create_field(main_layout, "Phone:", "phone_input")
        self.create_field(main_layout, "Email:", "email_input")
        self.create_field(main_layout, "Manufacturer Address:", "address_input")

        # Add Manufacturer button
        add_manufacturer_button = QPushButton("Add Manufacturer")
        add_manufacturer_button.setFont(QFont("Arial", 12, QFont.Bold))
        add_manufacturer_button.setStyleSheet("""
            QPushButton {
                background-color: #005A8D; 
                color: white; 
                padding: 8px; 
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
        """)
        add_manufacturer_button.clicked.connect(self.add_manufacturer)
        main_layout.addWidget(add_manufacturer_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12, QFont.Bold))
        label.setStyleSheet("color: #2c3e50;")  # Dark Text Color for labels

        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)
        input_field.setStyleSheet("""
            QLineEdit {
                background-color: #ecf0f1; 
                color: #2c3e50; 
                padding: 5px; 
                border: 1px solid #bdc3c7; 
                border-radius: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #3498db;
            }
        """)
        setattr(self, input_name, input_field)  # Dynamically create attributes
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def add_manufacturer(self):
        """
        Logic to handle adding a manufacturer when the button is clicked.
        """
        name = self.name_input.text()
        phone = self.phone_input.text()
        email = self.email_input.text()
        address = self.address_input.text()

        # Perform validation or save logic here
        if not name or not address or not phone or not email:
            print("Please fill all the fields!")
        else:
            try:
                connection = DatabaseConnection.get_connection()
                cursor = connection.cursor()

                query = '''INSERT INTO tbl_Manufacturer (manufacturer_name, manufacturer_phone, manufacturer_email, manufacturer_address)
                           VALUES (?, ?, ?, ?)'''

                cursor.execute(query, (name, phone, email, address))
                connection.commit()

                print(f"Manufacturer added: Name={name}, Phone={phone}, Email={email}, Address={address}")
                # Clear the fields after adding the manufacturer
                self.clear_fields()
                self.manufacturer_added.emit()

            except pyodbc.Error as e:
                print(f"Error adding manufacturer to the database: {e}")
            finally:
                cursor.close()

    def clear_fields(self):
        """
        Clears all input fields after adding a manufacturer.
        """
        self.name_input.clear()
        self.phone_input.clear()
        self.email_input.clear()
        self.address_input.clear()

