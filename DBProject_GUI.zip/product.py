import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QDialog, QMessageBox, QAbstractScrollArea
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, pyqtSignal

from AddProduct import AddProduct
from DBconnectivity import DatabaseConnection
from DeleteProduct import DeleteProduct
from QuantityDialog import QuantityDialog
from UpdateProduct import UpdateProduct
from orders import PharmacyPage
from QuantityDialog import QuantityDialog
from datetime import datetime

class ProductPage(QMainWindow):
    def __init__(self):
        super().__init__()

        # Set up the main window
        self.setWindowTitle("Medlink_Products")
        self.setGeometry(600, 200, 800, 600)
        self.setFixedHeight(700)
        self.setFixedWidth(955)

        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Medicine:")
        self.search_input = QLineEdit()
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(100)
        self.medicine_table.setColumnCount(7)
        self.medicine_table.setHorizontalHeaderLabels(["Product_ID","Product Name", "Unit_Price", "Cost_Price", "Manufacture_Date", "Expiry_Date", "Quantity", "Category"])
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        add_button = QPushButton("Add Product")
        update_button = QPushButton("Update Product")
        delete_button = QPushButton("Delete Product")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(add_button)

        buttons_layout.addWidget(update_button)
        buttons_layout.addWidget(delete_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by FHH | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Central widget setup
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        add_button.clicked.connect(self.show_addProduct)
        update_button.clicked.connect(self.show_update_product)
        delete_button.clicked.connect(self.show_delete_product)
        exit_button.clicked.connect(self.close)

        self.display_products()
        self.medicine_table.cellClicked.connect(self.row_clicked)

    def search_medicine(self):
        # Get the search query from the input field
        search_input = self.search_input.text()
        try:
            # Establish database connection
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Execute the stored procedure with the search query as a parameter
            cursor.execute("EXEC SearchProductByName @ProductName = ?", (search_input,))
            # Fetch the results
            results = cursor.fetchall()

            # Clear the table before populating new results
            self.medicine_table.setRowCount(0)

            # Populate the QTableWidget with the search results
            for row_index, product in enumerate(results):
                self.medicine_table.insertRow(row_index)
                for col_index, value in enumerate(product):
                    self.medicine_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

            # Check if no results were found
            if not results:
                QMessageBox.information(self, "No Results", "No products found matching the search query.")

        except Exception as e:
            # Show error message if any issues occur
            QMessageBox.critical(self, "Database Error", f"Failed to fetch data: {e}")
            print("Database Error:", e)

    def display_products(self):
        try:
            # Establish database connection
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Query to fetch data from the tbl_Products table
            display_query = "SELECT * FROM view_product order by product_name"
            cursor.execute(display_query)

            # Fetch all rows from the executed query
            products = cursor.fetchall()

            # Set the row count dynamically based on fetched data
            self.medicine_table.setRowCount(len(products))

            # Populate the QTableWidget with data
            for row_index, product in enumerate(products):
                for col_index, value in enumerate(product):
                    self.medicine_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

        except Exception as e:  # General exception for broader error handling
            QMessageBox.critical(self, "Database Error", f"Failed to fetch data: {e}")
            print("Database Error:", e)

    def row_clicked(self, row, column):
        try:
            # Extract data from the clicked row
            row_data = []
            for col in [0, 1, 2, 4, 5, 6]:  # Columns to extract data from
                item = self.medicine_table.item(row, col)
                row_data.append(item.text() if item else "")
            row_data.append(1)
            row_data.append(1)

            print(row_data)

            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # SQL INSERT query
            insert_query = """
                               INSERT INTO order_on_board (product_id, product_name, amount, manufacture_date, exp_date, quantity)
                               VALUES (?, ?, ?, ?, ?, ?);
                           """
            cursor.execute(insert_query, (
                int(row_data[0]),
                row_data[1],
                float(row_data[2]),
                row_data[3],
                row_data[4],
                int(row_data[6]),
            ))
            # Commit the transaction
            connection.commit()
            # print(row_data)
        except Exception as e:
            print(f"Error in row_clicked: {e}")
            QMessageBox.critical(self, "Error", f"An error occurred: {e}")
            print("Error:", e)

    def search_medicine(self):
        search_input = self.search_input.text()
        try:
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            cursor.execute("EXEC SearchProductByName @ProductName = ?", (search_input,))
            results = cursor.fetchall()

            self.medicine_table.setRowCount(0)  # Clear the table

            for row_index, product in enumerate(results):
                self.medicine_table.insertRow(row_index)
                for col_index, value in enumerate(product):
                    self.medicine_table.setItem(row_index, col_index, QTableWidgetItem(str(value)))

            if not results:
                QMessageBox.information(self, "No Results", "No products found matching the search query.")
        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Failed to fetch data: {e}")
            print("Database Error:", e)

    def show_addProduct(self):
        self.product_page = AddProduct()  # Create a new instance of AddProductsPage
        self.product_page.show()

    def show_update_product(self):
        self.product = UpdateProduct()
        self.product.show()

    def show_delete_product(self):
        self.product = DeleteProduct(self.medicine_table)
        self.product.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProductPage()
    window.show()
    sys.exit(app.exec_())