from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
'''
class UpdateManufacturer(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Update Manufacturer")
        self.setGeometry(800, 300, 400, 300)

        # Set background color to light blue
        self.setStyleSheet("background-color: lightblue;")

        # Simulated customer database (replace with actual database calls)
        #self.supplier_data = {
        #    "12345": {"name": "John Doe", "address": "123 Elm St", "phone": "555-1234", "email": "john@example.com"},
        #    "67890": {"name": "Jane Smith", "address": "456 Oak St", "phone": "555-5678", "email": "jane@example.com"}
        #}

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for customer details
        self.create_field(main_layout, "Manufacturer Name:", "name_input")
        self.create_field(main_layout, "Address:", "address_input")
        self.create_field(main_layout, "Phone:", "phone_input")
        self.create_field(main_layout, "Email:", "email_input")

        # Update Customer button
        update_customer_button = QPushButton("Update Manufacturer")
        update_customer_button.setFont(QFont("Arial", 12))
        update_customer_button.setStyleSheet(
            "background-color: blue; color: white; padding: 5px; border-radius: 5px;"
        )
        update_customer_button.clicked.connect(self.update_manufacturer)
        main_layout.addWidget(update_customer_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12))
        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)  # Set a fixed width for uniformity

        # Set white background for the input fields
        input_field.setStyleSheet("background-color: white; color: black; padding: 2px;")

        setattr(self, input_name, input_field)  # Dynamically create an attribute for each input field
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def update_manufacturer(self):
        """
        Validates the CNIC and name, then updates address, phone, and email.
        """
        name = self.name_input.text()
        address = self.address_input.text()
        phone = self.phone_input.text()
        email = self.email_input.text()
       
        # Validate CNIC and name
        if name in self.customer_data and self.customer_data[cnic]["name"] == name:
            # Update the address, phone, and email fields
            if address:
                self.customer_data[cnic]["address"] = address
            if phone:
                self.customer_data[cnic]["phone"] = phone
            if email:
                self.customer_data[cnic]["email"] = email

            QMessageBox.information(self, "Success", "Customer details updated successfully.")

        else:
            # Raise an exception if validation fails
            QMessageBox.critical(self, "Error", "CNIC and Name do not match any customer.")
      
    def clear_fields(self):
        """
        Clears all input fields after updating a customer.
        """
        self.name_input.clear()
        self.address_input.clear()
        self.phone_input.clear()
        self.email_input.clear()

# To test the UpdateCustomer widget independently
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = UpdateManufacturer()
    window.show()
    sys.exit(app.exec_())
'''
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QMessageBox, QHBoxLayout, QLineEdit, QLabel, QPushButton, QVBoxLayout, QWidget

from DBconnectivity import DatabaseConnection

'''
class UpdateManufacturer(QWidget):
    manufacturer_updated = pyqtSignal()
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Update Supplier")
        self.setGeometry(800, 300, 400, 300)

        # Set background color to light blue
        self.setStyleSheet("background-color: lightblue;")

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for customer details
        self.create_field(main_layout, "Manufacturer ID:", "id_input")
        self.create_field(main_layout, "Manufacturer Name:", "name_input")
        self.create_field(main_layout, "Phone:", "phone_input")
        self.create_field(main_layout, "Address:", "address_input")
        self.create_field(main_layout, "Email:", "email_input")

        # Update Customer button
        update_Manufacturer_button = QPushButton("Update Manufacturer")
        update_Manufacturer_button.setFont(QFont("Arial", 12))
        update_Manufacturer_button.setStyleSheet(
            "background-color: blue; color: white; padding: 5px; border-radius: 5px;"
        )
        update_Manufacturer_button.clicked.connect(self.update_manufacturer)
        main_layout.addWidget(update_Manufacturer_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12))
        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)  # Set a fixed width for uniformity

        # Set white background for the input fields
        input_field.setStyleSheet("background-color: white; color: black; padding: 2px;")

        setattr(self, input_name, input_field)  # Dynamically create an attribute for each input field
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def update_manufacturer(self):
        """
        Validates the Customer ID, updates the details in the database, and refreshes the CustomerPage.
        """
        manufacturer_id = self.id_input.text()
        name = self.name_input.text()
        phone = self.phone_input.text()
        address = self.address_input.text()
        email = self.email_input.text()

        if not manufacturer_id:
            QMessageBox.warning(self, "Input Error", "Manufacturer ID is required.")
            return

        try:
            # Establish database connection
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()
            query = "SELECT * FROM tbl_Manufacturer WHERE manufacturer_ID = ?"

            # Check if customer exists
            cursor.execute(query, (manufacturer_id,))
            manufacturer = cursor.fetchone()

            if not manufacturer:
                QMessageBox.critical(self, "Error", "Manufacturer ID does not exist.")
                return

            # Update fields only if values are provided
            update_query = "UPDATE tbl_manufacturer SET"
            fields = []
            params = []

            if name:
                fields.append("manufacturer_name = ?")
                params.append(name)
            if phone:
                fields.append("manufacturer_phone = ?")
                params.append(phone)
            if address:
                fields.append("manufacturer_address = ?")
                params.append(address)
            if email:
                fields.append("manufacturer_email = ?")
                params.append(email)


            if fields:
                update_query += " " + ", ".join(fields) + " WHERE manufacturer_ID = ?"
                params.append(manufacturer_id)
                cursor.execute(update_query, params)
                connection.commit()
                QMessageBox.information(self, "Success", "Manufacturer details updated successfully.")
            else:
                QMessageBox.warning(self, "Input Error", "No fields to update provided.")
            self.manufacturer_updated.emit()

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error updating manufacturer: {e}")

        finally:
            cursor.close()

    def clear_fields(self):
        """
        Clears all input fields after updating a customer.
        """
        self.id_input.clear()
        self.name_input.clear()
        self.phone_input.clear()
        self.email_input.clear()
        self.address_input.clear()
'''
class UpdateManufacturer(QWidget):
    manufacturer_updated = pyqtSignal()

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Update Manufacturer")
        self.setGeometry(800, 300, 400, 300)

        # Set background color to a neutral light tone
        self.setStyleSheet("background-color: #f5f6fa;")  # Light Gray Background

        # Main layout container
        main_layout = QVBoxLayout()

        # Add labels and text fields for manufacturer details
        self.create_field(main_layout, "Manufacturer ID:", "id_input")
        self.create_field(main_layout, "Manufacturer Name:", "name_input")
        self.create_field(main_layout, "Phone:", "phone_input")
        self.create_field(main_layout, "Address:", "address_input")
        self.create_field(main_layout, "Email:", "email_input")

        # Update Manufacturer button
        update_manufacturer_button = QPushButton("Update Manufacturer")
        update_manufacturer_button.setFont(QFont("Arial", 12, QFont.Bold))
        update_manufacturer_button.setStyleSheet("""
            QPushButton {
                background-color: #005A8D; 
                color: white; 
                padding: 8px; 
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
        """)
        update_manufacturer_button.clicked.connect(self.update_manufacturer)
        main_layout.addWidget(update_manufacturer_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def create_field(self, layout, label_text, input_name):
        """
        Helper function to create a label and input field and add it to the layout.
        """
        field_layout = QHBoxLayout()
        label = QLabel(label_text)
        label.setFont(QFont("Arial", 12, QFont.Bold))
        label.setStyleSheet("color: #2c3e50;")  # Dark Text Color for labels

        input_field = QLineEdit()
        input_field.setFont(QFont("Arial", 12))
        input_field.setFixedWidth(250)
        input_field.setStyleSheet("""
            QLineEdit {
                background-color: #ecf0f1; 
                color: #2c3e50; 
                padding: 5px; 
                border: 1px solid #bdc3c7; 
                border-radius: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #3498db;
            }
        """)
        setattr(self, input_name, input_field)  # Dynamically create attributes
        field_layout.addWidget(label)
        field_layout.addWidget(input_field)
        layout.addLayout(field_layout)

    def update_manufacturer(self):
        """
        Validates the Manufacturer ID, updates the details in the database, and refreshes the ManufacturerPage.
        """
        manufacturer_id = self.id_input.text()
        name = self.name_input.text()
        phone = self.phone_input.text()
        address = self.address_input.text()
        email = self.email_input.text()

        if not manufacturer_id:
            QMessageBox.warning(self, "Input Error", "Manufacturer ID is required.")
            return

        try:
            # Establish database connection
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()
            query = "SELECT * FROM tbl_manufacturer WHERE manufacturer_ID = ?"

            # Check if manufacturer exists
            cursor.execute(query, (manufacturer_id,))
            manufacturer = cursor.fetchone()

            if not manufacturer:
                QMessageBox.critical(self, "Error", "Manufacturer ID does not exist.")
                return

            # Update fields only if values are provided
            update_query = "UPDATE tbl_manufacturer SET"
            fields = []
            params = []

            if name:
                fields.append("manufacturer_name = ?")
                params.append(name)
            if phone:
                fields.append("manufacturer_phone = ?")
                params.append(phone)
            if address:
                fields.append("manufacturer_address = ?")
                params.append(address)
            if email:
                fields.append("manufacturer_email = ?")
                params.append(email)

            if fields:
                update_query += " " + ", ".join(fields) + " WHERE manufacturer_ID = ?"
                params.append(manufacturer_id)
                cursor.execute(update_query, params)
                connection.commit()
                QMessageBox.information(self, "Success", "Manufacturer details updated successfully.")

                # Clear the fields after updating the manufacturer
                self.clear_fields()

                # Emit the signal to notify about the update
                self.manufacturer_updated.emit()
            else:
                QMessageBox.warning(self, "Input Error", "No fields to update provided.")

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Error updating manufacturer: {e}")

        finally:
            cursor.close()

    def clear_fields(self):
        """
        Clears all input fields after updating a manufacturer.
        """
        self.id_input.clear()
        self.name_input.clear()
        self.phone_input.clear()
        self.email_input.clear()
        self.address_input.clear()


