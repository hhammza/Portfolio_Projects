import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt


class PharmacyFrontPage(QMainWindow):
    def __init__(self):
        super().__init__()

        # Set up the main window
        self.setWindowTitle("Medlink")
        self.setGeometry(100, 100, 800, 600)

        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Medicine:")
        search_input = QLineEdit()
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(5)
        self.medicine_table.setColumnCount(6)
        self.medicine_table.setHorizontalHeaderLabels(["Product Code", "Product Name", "Price", "Cost Price", "Stock", "Batch number"])
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        bill_button = QPushButton("Billing")
        inventory_button = QPushButton("Inventory")
        reports_button = QPushButton("Reports")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(bill_button)
        buttons_layout.addWidget(inventory_button)
        buttons_layout.addWidget(reports_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by Candela | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Central widget setup
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        exit_button.clicked.connect(self.close)

    def search_medicine(self):
        # Placeholder for search logic
        print("Search functionality triggered!")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PharmacyFrontPage()
    window.show()
    sys.exit(app.exec_())
