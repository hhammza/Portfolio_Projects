import sys

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox, QApplication
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

from DBconnectivity import DatabaseConnection

'''
class DeleteCustomer(QWidget):
    def __init__(self, customer_table):
        super().__init__()
        self.customer_table = customer_table

        # Set window properties
        self.setWindowTitle("Delete Customer")
        self.setGeometry(300, 200, 400, 200)

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Customer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        cnic_label = QLabel("Customer CNIC:")
        self.cnic_input = QLineEdit()
        self.cnic_input.setPlaceholderText("Enter CNIC")
        input_layout.addWidget(cnic_label)
        input_layout.addWidget(self.cnic_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        self.delete_button = QPushButton("Delete Customer")
        self.delete_button.setStyleSheet("background-color: blue; color: white; padding: 5px 15px;")
        self.delete_button.clicked.connect(self.delete_customer)
        main_layout.addWidget(self.delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_customer(self):
        cnic_to_delete = self.cnic_input.text().strip()

        if not cnic_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid CNIC.")
            return

        # Search for the customer in the table
        for row in range(self.customer_table.rowCount()):
            cnic_item = self.customer_table.item(row, 0)  # Assuming CNIC is in column 0
            if cnic_item and cnic_item.text() == cnic_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the customer with CNIC: {cnic_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.customer_table.removeRow(row)
                    QMessageBox.information(self, "Success", "Customer deleted successfully.")
                return

        QMessageBox.warning(self, "Not Found", "Customer with the specified CNIC does not exist.")
if __name__ == "__main__":
    from PharmacySystem.GUI_DB.customer import CustomerPage
    app = QApplication(sys.argv)
    window = DeleteCustomer()
    window.show()
    sys.exit(app.exec_())'''

'''
class DeleteCustomer(QWidget):
    def __init__(self, customer_table):
        super().__init__()
        self.customer_table = customer_table

        # Set window properties
        self.setWindowTitle("Delete Customer")
        self.setGeometry(300, 200, 400, 200)

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Customer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        id_label = QLabel("Customer ID:")
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("Enter Customer ID")
        input_layout.addWidget(id_label)
        input_layout.addWidget(self.id_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        self.delete_button = QPushButton("Delete Customer")
        self.delete_button.setStyleSheet("background-color: blue; color: white; padding: 5px 15px;")
        self.delete_button.clicked.connect(self.delete_customer)
        main_layout.addWidget(self.delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_customer(self):
        customer_id_to_delete = self.id_input.text().strip()

        if not customer_id_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Customer ID.")
            return

        # Search for the customer in the table
        for row in range(self.customer_table.rowCount()):
            id_item = self.customer_table.item(row, 0)  # Assuming Customer ID is in column 0
            if id_item and id_item.text() == customer_id_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the customer with ID: {customer_id_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.customer_table.removeRow(row)

                    # Database deletion logic
                    connection = DatabaseConnection.get_connection()
                    cursor = connection.cursor()
                    try:
                        query = "DELETE FROM tbl_Customer WHERE customer_id = ?"
                        cursor.execute(query, (customer_id_to_delete,))
                        connection.commit()
                        QMessageBox.information(self, "Success", "Customer deleted successfully.")
                    except Exception as e:
                        QMessageBox.critical(self, "Database Error", f"Error deleting customer: {e}")
                    finally:
                        cursor.close()
                return

        QMessageBox.warning(self, "Not Found", "Customer with the specified ID does not exist.")'''


class DeleteCustomer(QWidget):
    def __init__(self, customer_table):
        super().__init__()
        self.customer_table = customer_table

        # Set window properties
        self.setWindowTitle("Delete Customer")
        self.setGeometry(800, 300, 400, 200)

        # Set background color to match AddCustomer
        self.setStyleSheet("background-color: #f5f6fa;")  # Light Gray Background

        # Main layout
        main_layout = QVBoxLayout()

        # Header Label
        header_label = QLabel("Delete Customer")
        header_label.setFont(QFont("Arial", 16, QFont.Bold))
        header_label.setAlignment(Qt.AlignCenter)
        header_label.setStyleSheet("color: #2c3e50;")  # Dark Text Color
        main_layout.addWidget(header_label)

        # Input Field Section
        input_layout = QHBoxLayout()
        id_label = QLabel("Customer ID:")
        id_label.setFont(QFont("Arial", 12, QFont.Bold))
        id_label.setStyleSheet("color: #2c3e50;")

        self.id_input = QLineEdit()
        self.id_input.setFont(QFont("Arial", 12))
        self.id_input.setFixedWidth(250)
        self.id_input.setStyleSheet("""
            QLineEdit {
                background-color: #ecf0f1; 
                color: #2c3e50; 
                padding: 5px; 
                border: 1px solid #bdc3c7; 
                border-radius: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #3498db;
            }
        """)
        self.id_input.setPlaceholderText("Enter Customer ID")
        input_layout.addWidget(id_label)
        input_layout.addWidget(self.id_input)
        main_layout.addLayout(input_layout)

        # Delete Button
        delete_button = QPushButton("Delete Customer")
        delete_button.setFont(QFont("Arial", 12, QFont.Bold))
        delete_button.setStyleSheet("""
            QPushButton {
                background-color: #005A8D; 
                color: white; 
                padding: 8px; 
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #34495e;
            }
        """)
        delete_button.clicked.connect(self.delete_customer)
        main_layout.addWidget(delete_button, alignment=Qt.AlignCenter)

        self.setLayout(main_layout)

    def delete_customer(self):
        customer_id_to_delete = self.id_input.text().strip()

        if not customer_id_to_delete:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Customer ID.")
            return

        # Search for the customer in the table
        for row in range(self.customer_table.rowCount()):
            id_item = self.customer_table.item(row, 0)  # Assuming Customer ID is in column 0
            if id_item and id_item.text() == customer_id_to_delete:
                # Confirm deletion
                confirm = QMessageBox.question(
                    self,
                    "Confirm Deletion",
                    f"Are you sure you want to delete the customer with ID: {customer_id_to_delete}?",
                    QMessageBox.Yes | QMessageBox.No
                )

                if confirm == QMessageBox.Yes:
                    self.customer_table.removeRow(row)

                    # Database deletion logic
                    connection = DatabaseConnection.get_connection()
                    cursor = connection.cursor()
                    try:
                        query = "DELETE FROM tbl_Customer WHERE customer_id = ?"
                        cursor.execute(query, (customer_id_to_delete,))
                        connection.commit()
                        QMessageBox.information(self, "Success", "Customer deleted successfully.")
                    except Exception as e:
                        QMessageBox.critical(self, "Database Error", f"Error deleting customer: {e}")
                    finally:
                        cursor.close()
                return

        QMessageBox.warning(self, "Not Found", "Customer with the specified ID does not exist.")

