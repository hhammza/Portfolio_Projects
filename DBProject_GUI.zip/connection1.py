import pyodbc

class DatabaseConnection:
    _connection = None

    @staticmethod
    def get_connection():
        if DatabaseConnection._connection is None:
            try:
                # Define connection parameters
                server = r'DESKTOP-7LVJP7N\SQLEXPRESS'  # Use raw string to avoid escape issues
                database = 'db_PharmacyProject'  # Replace with your database name

                # Create the connection string
                connection_string = (
                    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
                    f'SERVER={server};DATABASE={database};Trusted_Connection=yes'
                )

                # Establish the connection
                DatabaseConnection._connection = pyodbc.connect(connection_string)
                print("Database connection established!")
            except pyodbc.Error as e:
                print("Error connecting to SQL Server:", e)
                raise
        return DatabaseConnection._connection