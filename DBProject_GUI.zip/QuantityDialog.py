from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QDialogButtonBox, QMessageBox

class QuantityDialog(QDialog):
    def __init__(self, product_name, max_stock, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Select Quantity for {product_name}")
        self.selected_quantity = 0
        #self.max_stock = max_stock

        layout = QVBoxLayout()

        label = QLabel(f"Enter quantity (Available stock: {max_stock}):")
        self.quantity_input = QLineEdit()
        self.quantity_input.setPlaceholderText("Enter quantity")

        layout.addWidget(label)
        layout.addWidget(self.quantity_input)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept_quantity)
        buttons.rejected.connect(self.reject)

        layout.addWidget(buttons)
        self.setLayout(layout)

    def accept_quantity(self):
        try:
            self.selected_quantity = int(self.quantity_input.text())
            if self.selected_quantity <= 0: #or quantity > self.max_stock:
                raise ValueError("Quality must be greater than 0")
            #self.selected_quantity = quantity
            self.accept()
        except ValueError:
            QMessageBox.critical(self, "Invalid Input", "Please enter a valid quantity within the stock range.")
