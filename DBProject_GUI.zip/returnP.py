import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QSizePolicy, QHeaderView
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt



'''
class ReturnPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback
    
        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Search Medicine:")
        search_input = QLineEdit()
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(1000)
        self.medicine_table.setColumnCount(10)
        self.medicine_table.setHorizontalHeaderLabels(["Order Code", "Product Code", "Product name", "Qty", "Price", "Order Date", "Discount", "Delivery Date",
             "Payment Method", "Return Date"])
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        return_button = QPushButton("Return History")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(return_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by Candela | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Signals and Slots
        search_button.clicked.connect(self.search_medicine)
        exit_button.clicked.connect(self.close)
        
        self.setLayout(main_layout)

    def search_medicine(self):
        # Placeholder for search logic
        print("Search functionality triggered!")'''
'''
import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from PharmacySystem.GUI_DB.DBconnectivity import DatabaseConnection


class ReturnPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback

        # Main layout container
        main_layout = QVBoxLayout()

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Enter Order ID:")
        self.search_input = QLineEdit()  # Make the input accessible for search logic
        self.search_input.setPlaceholderText("Enter Order ID here")
        search_button = QPushButton("Search")
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying medicines
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(1)  # One row since only one order is fetched
        self.medicine_table.setColumnCount(10)
        self.medicine_table.setHorizontalHeaderLabels([
            "Order Code", "Product Code", "Product Name", "Qty", "Price",
            "Discount", "Order Date", "Delivery Date", "Payment Method", "Return Date", "Customer ID"
        ])
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        save_button = QPushButton("Save")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(save_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by Candela | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Signals and Slots
        search_button.clicked.connect(self.search_order)
        exit_button.clicked.connect(self.close)

        self.setLayout(main_layout)

    def search_order(self):
        # Get the entered Order ID
        order_id = self.search_input.text().strip()

        if not order_id:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Order ID.")
            return

        # Database connection
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()

        try:
            # Query to fetch order details based on Order ID
            query = """
                SELECT order_ID, productName, qty, amount, discount,
                       order_date, delivery_date, payment_method, returnDate, customerID
                FROM tbl_ReturnPurchase
                WHERE order_ID = %s
            """
            cursor.execute(query, (order_id,))
            order_data = cursor.fetchone()  # Fetch a single row

            if not order_data:
                QMessageBox.warning(self, "Not Found", f"No data found for Order ID: {order_id}")
                return

            # Populate the table row with the order data
            for col_index, value in enumerate(order_data):
                self.medicine_table.setItem(0, col_index, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
        finally:
            cursor.close()
            connection.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ReturnPage(None)
    window.show()
    sys.exit(app.exec_())'''
import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QWidget, QTableWidget, QTableWidgetItem, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from DBconnectivity import DatabaseConnection


class ReturnPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.switch_callback = switch_callback

        # Main layout container
        main_layout = QVBoxLayout()

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header_label)

        # Search Section
        search_layout = QHBoxLayout()
        search_label = QLabel("Enter Order ID:")
        search_label.setStyleSheet("color: #005A8D; font-weight: bold;")
        self.search_input = QLineEdit()  # Make the input accessible for search logic
        self.search_input.setPlaceholderText("Enter Order ID here")
        self.search_input.setStyleSheet("background-color: #FFFFFF; border: 1px solid #A0C4FF; border-radius: 5px;")
        search_button = QPushButton("Search")
        search_button.setStyleSheet(
            "background-color: #4CAF50; color: white; font-weight: bold; border-radius: 5px; padding: 5px;"
        )
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_button)
        main_layout.addLayout(search_layout)

        # Table Section for displaying order details
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(1)  # One row since only one order is fetched
        self.medicine_table.setColumnCount(10)
        self.medicine_table.setHorizontalHeaderLabels([
            "Order Code", "Product Code", "Product Name", "Qty", "Price",
            "Discount", "Order Date", "Delivery Date", "Payment Method", "Return Date", "salesman ID"
        ])

        # Style for the Table Header
        self.medicine_table.horizontalHeader().setStyleSheet("""
            QHeaderView::section {
                background-color: #005A8D;
                color: white;
                padding: 5px;
                font-weight: bold;
            }
        """)
        self.medicine_table.setStyleSheet("alternate-background-color: #F2F2F2; background-color: white;")
        self.medicine_table.setAlternatingRowColors(True)

        # Resize policies for the table
        self.medicine_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.medicine_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.medicine_table.setMinimumHeight(400)  # Ensure it takes a reasonable height
        main_layout.addWidget(self.medicine_table)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        button_style = "background-color: #005A8D; color: white; font-weight: bold; border-radius: 5px; padding: 5px;"
        save_button = QPushButton("Save")
        save_button.setStyleSheet(button_style)
        exit_button = QPushButton("Exit")
        exit_button.setStyleSheet("background-color: #005A8D; color: white; font-weight: bold; border-radius: 5px; padding: 5px;")
        buttons_layout.addWidget(save_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by Candela | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray; background-color: #F7F7F7; padding: 5px; border-radius: 5px;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        # Signals and Slots
        search_button.clicked.connect(self.search_order)
        exit_button.clicked.connect(self.close)

        self.setLayout(main_layout)


    def search_order(self):
        # Get the entered Order ID
        order_id = self.search_input.text().strip()

        if not order_id:
            QMessageBox.warning(self, "Input Error", "Please enter a valid Order ID.")
            return

        # Database connection
        connection = DatabaseConnection.get_connection()
        cursor = connection.cursor()

        try:
            # Query to fetch order details based on Order ID
            query = """
                SELECT order_ID, productName, qty, amount, discount,
                       order_date, delivery_date, payment_method, returnDate, customerID
                FROM tbl_ReturnPurchase
                WHERE order_ID = %s
            """
            cursor.execute(query, (order_id,))
            order_data = cursor.fetchone()  # Fetch a single row

            if not order_data:
                QMessageBox.warning(self, "Not Found", f"No data found for Order ID: {order_id}")
                return

            # Populate the table row with the order data
            for col_index, value in enumerate(order_data):
                self.medicine_table.setItem(0, col_index, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
        finally:
            cursor.close()
            connection.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ReturnPage(None)
    window.show()
    sys.exit(app.exec_())