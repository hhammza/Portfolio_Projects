from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QTableWidget, QFrame, QTableWidgetItem, QMessageBox
)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from calculator import Calculator
from InventoryReport import InventoryTable
from connection1 import DatabaseConnection
from bill import BillGenerator

class PharmacyPage(QWidget):
    def __init__(self, switch_callback):
        super().__init__()
        self.bill = BillGenerator
        self.switch_callback = switch_callback
        
        # Main layout container
        main_layout = QVBoxLayout()

        # Add a horizontal line after the header
        horizontal_line = QFrame()
        horizontal_line.setFrameShape(QFrame.HLine)
        horizontal_line.setFrameShadow(QFrame.Sunken)
        horizontal_line.setStyleSheet("color: lightgray;")
        main_layout.addWidget(horizontal_line)

        # Input Fields Section
        self.customer_name_input = QLineEdit()
        self.address_input = QLineEdit()
        self.contact_input = QLineEdit()
        self.email_input = QLineEdit()

        fields_layout_1 = QHBoxLayout()
        customer_name_label = QLabel("Customer Name:")
        address_label = QLabel("Address:")
        fields_layout_1.addWidget(customer_name_label)
        fields_layout_1.addWidget(self.customer_name_input)
        fields_layout_1.addWidget(address_label)
        fields_layout_1.addWidget(self.address_input)
        main_layout.addLayout(fields_layout_1)

        fields_layout_2 = QHBoxLayout()
        contact_label = QLabel("Contact:")
        email_label = QLabel("Email:")
        fields_layout_2.addWidget(contact_label)
        fields_layout_2.addWidget(self.contact_input)
        fields_layout_2.addWidget(email_label)
        fields_layout_2.addWidget(self.email_input)
        main_layout.addLayout(fields_layout_2)

        fields_layout_3 = QHBoxLayout()
        net_total_label = QLabel("Net Total:")
        self.net_total_input = QLineEdit()
        fields_layout_3.addWidget(net_total_label)
        fields_layout_3.addWidget(self.net_total_input)

        main_layout.addLayout(fields_layout_3)

        # Table Section: Initialize the table here
        self.medicine_table = QTableWidget()
        self.medicine_table.setRowCount(0)
        self.medicine_table.setColumnCount(6)
        self.medicine_table.setHorizontalHeaderLabels([
            "Product Name", "Amount", "Manufac_Date", "Exp_Date", "Quantity", "Discount"
        ])
        self.medicine_table.horizontalHeader().setStyleSheet(
            "QHeaderView::section { background-color: blue; color: white; font-weight: bold; }"
        )
        main_layout.addWidget(self.medicine_table)
        
        self.add_btn = QPushButton("ADD")
        self.add_btn.clicked.connect(self.add_rows_from_db)
        main_layout.addWidget(self.add_btn)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        self.calculator_button = QPushButton("Calculator")
        self.calculator_button.clicked.connect(self.open_calculator)
        self.inventory_button = QPushButton("Inventory")
        self.inventory_button.clicked.connect(self.show_inventory)
        self.print_receipt_button = QPushButton("Print Receipts")
        self.print_receipt_button.clicked.connect(self.combined)
        exit_button = QPushButton("Exit")
        exit_button.clicked.connect(self.close)

        buttons_layout.addWidget(self.calculator_button)
        buttons_layout.addWidget(self.inventory_button)
        buttons_layout.addWidget(self.print_receipt_button)
        buttons_layout.addWidget(exit_button)
        main_layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by FHH | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(footer_label)

        self.setLayout(main_layout)

    def add_rows_from_db(self):
        try:
            # Step 1: Connect to the database
            connection = DatabaseConnection.get_connection()
            cursor = connection.cursor()

            # Step 2: Fetch data from 'order_on_board' table
            query1 = "SELECT product_name, amount, manufacture_date, exp_date, quantity, discount FROM order_on_board"
            cursor.execute(query1)
            rows = cursor.fetchall()

            # Step 3: Check if the table exists
            if not hasattr(self, 'medicine_table') or self.medicine_table is None:
                print("Medicine table is not initialized.")
                return

            # Step 4: Insert data into the QTableWidget
            for row_data in rows:
                row_count = self.medicine_table.rowCount()
                self.medicine_table.insertRow(row_count)

                # Populate columns with data
                for col_index, value in enumerate(row_data):
                    self.medicine_table.setItem(row_count, col_index, QTableWidgetItem(str(value)))

            print("All rows successfully added from the database.")

            query2 = "truncate Table order_on_board"
            cursor.execute(query2)

        except pyodbc.Error as db_error:
            print(f"Database error: {db_error}")
            QMessageBox.critical(self, "Database Error", f"An error occurred: {db_error}")
        except Exception as e:
            print(f"Error in add_rows_from_db: {e}")
            QMessageBox.critical(self, "Error", f"An unexpected error occurred: {e}")

    def calculate_total_bill_amount(self):
        try:
            total_bill = 0.0  # Initialize total bill amount
            row_data = []

            # Loop through all rows in the table
            for row in range(self.medicine_table.rowCount()):
                # Get quantity and price values from the respective columns
                quantity_item = self.medicine_table.item(row, 1)  # Column index 4: "Qty"
                price_item = self.medicine_table.item(row, 4)  # Column index 1: "Price"
                row_data.append([
                    self.medicine_table.item(row, 0).text() if self.medicine_table.item(row, 0) else "N/A",
                    self.medicine_table.item(row, 1).text() if self.medicine_table.item(row, 1) else "0",
                    self.medicine_table.item(row, 4).text() if self.medicine_table.item(row, 4) else "0",
                    self.customer_name_input.text()
                ])

                # Check if the table cells are not empty
                if quantity_item and price_item:
                    try:
                        quantity = float(quantity_item.text())
                        price = float(price_item.text())

                        # Calculate the total price for this row and add to the total bill
                        total_bill += quantity * price
                    except ValueError:
                        # Skip rows with invalid (non-numeric) quantity or price values
                        print(f"Skipping row {row + 1}: Invalid quantity or price value.")

            print(f"Total Bill Amount: {total_bill}", row_data)
            self.net_total_input.setText(str(total_bill))
            return row_data  # Return the calculated total amount
        except Exception as e:
            print(f"Error calculating total bill amount: {e}")
            return 0.0

    def submit_details(self):
        try:
            # Retrieve input data
            customer_name = self.customer_name_input.text().strip()
            address = self.address_input.text().strip()
            phone = self.contact_input.text().strip()
            email = self.email_input.text().strip()

            # If email or address is not provided, set default values
            if not email:
                email = 'not_provided'
            if not address:
                address = 'not_provided'

            # Validate customer name and phone
            if not customer_name or not phone:
                QMessageBox.warning(self, "Input Error", "Customer Name and Contact are required!")
                return

            # Database operation
            connection = DatabaseConnection.get_connection()  # Ensure this method exists
            cursor = connection.cursor()

            # SQL INSERT query to add customer
            insert_query = """
                INSERT INTO tbl_customer (customer_name, customer_phone, customer_email, customer_address)
                VALUES (?, ?, ?, ?);
            """

            # Execute the query with provided data
            cursor.execute(insert_query, (customer_name, phone, email, address))

            # Commit the transaction
            connection.commit()

            # Display success message
            QMessageBox.information(self, "Success", "Customer added successfully!")

            # Clear input fields
            self.customer_name_input.clear()
            self.contact_input.clear()
            self.email_input.clear()
            self.address_input.clear()

        except Exception as e:
            # Show error message if something goes wrong
            QMessageBox.critical(self, "Error", f"An error occurred: {e}")
            print("Error:", e)

    def combined(self):
        self.submit_details()
        self.bill_data = self.calculate_total_bill_amount()
        self.send_data_to_bill()

    def send_data_to_bill(self):
        # Collect row data from the table
        row_data = []
        for row in range(self.medicine_table.rowCount()):
            product_item = self.medicine_table.item(row, 0)
            quantity_item = self.medicine_table.item(row, 1)
            price_item = self.medicine_table.item(row, 2)

            # Extract and sanitize data
            product = product_item.text() if product_item else "Unknown Product"
            quantity = quantity_item if quantity_item and quantity_item.text().isdigit() else "0"
            price = price_item.text() if price_item and self.is_float(price_item.text()) else "0.0"
            customer_name = self.customer_name_input.text() or "Unknown Customer"

            row_data.append([product, quantity, price, customer_name])

        # Debug the row data before passing
        print("Sanitized Row Data: ", row_data)

        # Open the BillGenerator dialog
        self.bill_window = BillGenerator(row_data=row_data, parent=self)
        self.bill_window.exec_()

    # Helper method to check if a string can be converted to float
    def is_float(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    # def send_data_to_bill(self):
    #     # Collect row data from the table
    #     row_data = []
    #     for row in range(self.medicine_table.rowCount()):
    #         product_item = self.medicine_table.item(row, 0)
    #         quantity_item = self.medicine_table.item(row, 1)
    #         price_item = self.medicine_table.item(row, 2)
    # 
    #         product = product_item.text() if product_item else "Unknown Product"
    #         quantity = quantity_item.text() if quantity_item else "0"
    #         price = price_item.text() if price_item else "0.0"
    #         customer_name = self.customer_name_input.text() or "Unknown Customer"
    # 
    #         row_data.append([product, quantity, price, customer_name])
    # 
    #     # Open the BillGenerator dialog
    #     self.bill_window = BillGenerator(row_data=row_data, parent=self)
    #     self.bill_window.exec_()

    def open_calculator(self):
        self.calculator_window = Calculator()
        self.calculator_window.setWindowTitle("Calculator")
        self.calculator_window.setGeometry(100, 100, 250, 250)
        self.calculator_window.show()

    def show_inventory(self):
        self.inventory_page = InventoryTable()
        self.inventory_page.setWindowTitle("Inventory")
        self.inventory_page.setGeometry(100, 100, 800, 600)
        self.inventory_page.show()