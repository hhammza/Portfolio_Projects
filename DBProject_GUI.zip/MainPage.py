import sys
from PyQt5.QtWidgets import QApplication, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QLabel
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

from order import PharmacyPage
from customer import CustomerPage
from manufacturer import ManuPage
from returnP import ReturnPage
from supplier import SupplierPage
from product import ProductPage

# Main Window Class
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Main layout
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Header Section
        header_label = QLabel("Medlink Pharmacy")
        header_label.setFont(QFont("Arial", 20, QFont.Bold))
        header_label.setStyleSheet("color: darkblue;")
        header_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(header_label)

        # Create content widgets
        self.customer = CustomerPage(self.show_order)
        self.order = PharmacyPage(self.show_customer)
        self.manu = ManuPage(self.show_manufac)
        self.returns = ReturnPage(self.show_returns)
        self.supp = SupplierPage(self.show_suppliers)

        # Buttons to switch content
        self.button_order = QPushButton("Home")
        self.button_customer = QPushButton("Customer")
        self.button_returns = QPushButton("Returns")
        self.button_manu = QPushButton("Manufacturers")
        self.button_supp = QPushButton("Suppliers")
        self.product = QPushButton("Products")

        # Connect buttons to methods
        self.button_order.clicked.connect(self.show_order)
        self.button_customer.clicked.connect(self.show_customer)
        self.button_returns.clicked.connect(self.show_returns)
        self.button_manu.clicked.connect(self.show_manufac)
        self.button_supp.clicked.connect(self.show_suppliers)
        self.product.clicked.connect(self.open_product_page)

        # Create a horizontal layout for buttons
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.button_order)
        button_layout.addWidget(self.button_customer)
        button_layout.addWidget(self.button_returns)
        button_layout.addWidget(self.button_supp)
        button_layout.addWidget(self.button_manu)
        button_layout.addWidget(self.product)

        # Add the horizontal button layout to the main layout
        self.layout.addLayout(button_layout)

        # Create a stretchable area for content (so footer stays at the bottom)
        self.content_layout = QVBoxLayout()
        self.content_layout.addWidget(self.order)  # Initially show the PharmacyPage content
        self.layout.addLayout(self.content_layout)

        # Buttons Section
        buttons_layout = QHBoxLayout()
        inventory_button = QPushButton("Inventory")
        exit_button = QPushButton("Exit")
        buttons_layout.addWidget(inventory_button)
        buttons_layout.addWidget(exit_button)
        self.layout.addLayout(buttons_layout)

        # Footer Section
        footer_label = QLabel("Developed by Candela | © 2024")
        footer_label.setFont(QFont("Arial", 10))
        footer_label.setStyleSheet("color: gray;")
        footer_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(footer_label)

        # Signals and Slots
        exit_button.clicked.connect(self.close)

    def switch_content(self, widget_to_show):
        # Remove the current content (if any)
        while self.content_layout.count():
            child = self.content_layout.takeAt(0)
            if child.widget():
                child.widget().setParent(None)

        # Add the new widget to the content layout
        self.content_layout.addWidget(widget_to_show)

    def show_customer(self):
        self.switch_content(self.customer)

    def show_order(self):
        self.switch_content(self.order)

    def show_manufac(self):
        self.switch_content(self.manu)

    def show_suppliers(self):
        self.switch_content(self.supp)

    def show_returns(self):
        self.switch_content(self.returns)

    def open_product_page(self):
        """Open the ProductPage in a new window."""
        self.product_page = ProductPage()  # Create a new instance of ProductPage
        self.product_page.show()

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())